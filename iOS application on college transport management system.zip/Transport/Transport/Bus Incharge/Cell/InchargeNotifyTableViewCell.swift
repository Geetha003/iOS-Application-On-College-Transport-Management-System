//
//  InchargeNotifyTableViewCell.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class InchargeNotifyTableViewCell: UITableViewCell {

    @IBOutlet weak var userIdLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var busIdLabel: UILabel!
    @IBOutlet weak var accpetButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
