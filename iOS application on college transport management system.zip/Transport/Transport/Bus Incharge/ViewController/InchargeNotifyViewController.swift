//
//  InchargeNotifyViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class InchargeNotifyViewController: UIViewController {
    
    @IBOutlet weak var inchargeNotifyTableView: UITableView!
    
    var details: InNotifications!
    var login : LoginModel!
    var accept : InAcceptButton!
    var reject : InRejectButton!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
//    let userId = String()
//    var busId = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.inchargeNotifyTableView.delegate = self
        self.inchargeNotifyTableView.dataSource = self
        
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchNotificationAPI() 
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    func fetchNotificationAPI() {
        APIHandler.shared.getAPIValues(type: InNotifications.self,  apiUrl: "\(ServiceAPI.InNotificationDetailsAPI)&userId=\(savedUserId)",method:"GET") { result in
            switch result {
            case .success(let data):
                self.details = data
                print(self.details.data ?? "")
                print(self.details.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.inchargeNotifyTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
            
            }
        }
    }
    
}

extension InchargeNotifyViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.details?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InchargeNotifyTableViewCell", for: indexPath) as! InchargeNotifyTableViewCell
        
        cell.accpetButton.tag = indexPath.row
        cell.accpetButton.addTarget(self, action: #selector(acceptButton(sender:)), for: .touchUpInside)
        
        cell.rejectButton.tag = indexPath.row
        cell.rejectButton.addTarget(self, action: #selector(rejectButton(sender:)), for: .touchUpInside)
        
        if let detail = self.details?.data?[indexPath.row] {
            cell.busIdLabel.text = ":     \(detail.busID ?? "")"
            cell.NameLabel.text = "Name:   \(detail.name ?? "")"
            cell.userIdLabel.text = "UserId:  \(detail.userID ?? "")"
          
        } else {
            cell.busIdLabel.text = "No data"
            cell.NameLabel.text = ""
            cell.userIdLabel.text = ""
           
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    @objc func acceptButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let busId = self.details.data?[rowToRemove].busID else {
            return
        }
        guard let userId = self.details.data?[rowToRemove].userID else {
            return
        }
    if let busIndex = self.details.data?.firstIndex(where: { $0.busID == busId }),
           let userIndex = self.details.data?.firstIndex(where: { $0.userID == userId }) {
            
            if userIndex == busIndex {
                // Remove the item at the common index
                self.details.data?.remove(at: userIndex)
                self.fetchNotificationAPI()
            }
        self.inchargeNotifyTableView.reloadData()
        let formData: [String: String] = ["student_id": userId, "bus_id": busId]
        APIHandler().postAPIValues(type: InAcceptButton.self, apiUrl: ServiceAPI.InAcceptButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.fetchNotificationAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}
    
    @objc func rejectButton(sender: UIButton) {
        let rowToRemove = sender.tag

        guard let busId = self.details.data?[rowToRemove].busID else {
            return
        }

        guard let userId = self.details.data?[rowToRemove].userID else {
            return
        }

        if let busIndex = self.details.data?.firstIndex(where: { $0.busID == busId }),
           let userIndex = self.details.data?.firstIndex(where: { $0.userID == userId }) {
            
            if userIndex == busIndex {
                // Remove the item at the common index
                self.details.data?.remove(at: userIndex)
                self.fetchNotificationAPI()
            }
        self.inchargeNotifyTableView.reloadData()
        let formData: [String: String] = ["student_id": userId, "bus_id": busId]
            APIHandler().postAPIValues(type: InRejectButton.self, apiUrl: ServiceAPI.InRejectButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.fetchNotificationAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}
    
}



