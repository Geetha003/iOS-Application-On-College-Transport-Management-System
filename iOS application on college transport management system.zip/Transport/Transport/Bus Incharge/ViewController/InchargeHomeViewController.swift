//
//  InchargeHomeViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class InchargeHomeViewController: UIViewController {
    
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var dashboardView: UIView!
    @IBOutlet weak var profileView: UIView!
    @IBOutlet weak var trackBusView: UIView!
    @IBOutlet weak var studentDetailsView: UIView!
    @IBOutlet weak var busInchargeView: UIView!
    @IBOutlet weak var trackBusImage: UIImageView!
    @IBOutlet weak var studentDetailsImage: UIImageView!
    @IBOutlet weak var busInchargeImage: UIImageView!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var userIdLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    
    let border = Border()
    var pass: Profile!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        dashboardView.isHidden = false
        profileView.isHidden = true
        menuView.isHidden = true
        
        border.viewBorder(to: trackBusView)
        border.viewBorder(to: studentDetailsView)
        border.viewBorder(to: busInchargeView)
        
        border.imageBorder(to: trackBusImage)
        border.imageBorder(to: studentDetailsImage)
        border.imageBorder(to: busInchargeImage)
        
        let tapGestureBusDetails = UITapGestureRecognizer(target: self, action: #selector(trackBusTap(_:)))
        trackBusView.addGestureRecognizer(tapGestureBusDetails)
        trackBusView.isUserInteractionEnabled = true
        
        let tapGestureStudent = UITapGestureRecognizer(target: self, action: #selector(studentDetailsTap(_:)))
        studentDetailsView.addGestureRecognizer(tapGestureStudent)
        studentDetailsView.isUserInteractionEnabled = true
        
        let tapGestureIncharge = UITapGestureRecognizer(target: self, action: #selector(inchargeDetailsTap(_:)))
        busInchargeView.addGestureRecognizer(tapGestureIncharge)
        busInchargeView.isUserInteractionEnabled = true
    }
    
    @objc func trackBusTap(_ sender: UITapGestureRecognizer) {
        
    }
    
    @objc func studentDetailsTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "AdminStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "StudentDetailsViewController") as! StudentDetailsViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func inchargeDetailsTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "AdminStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "InchargeViewController") as! InchargeViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func menuButtonAction(_ sender: Any) {
        if menuView.isHidden {
               menuView.isHidden = false
               dashboardView.isHidden = true
               profileView.isHidden = true
           } else {
               menuView.isHidden = true
               if segmentController.selectedSegmentIndex == 0 {
                   dashboardView.isHidden = false
                   profileView.isHidden = true
               } else if segmentController.selectedSegmentIndex == 1 {
                   dashboardView.isHidden = true
                   profileView.isHidden = false
               }
           }
    }
    
    @IBAction func segmentAction(_ sender: Any) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            dashboardView.isHidden = false
            profileView.isHidden = true
        case 1:
            dashboardView.isHidden = true
            profileView.isHidden = false
        default:
            break
        }
    }
    
    @IBAction func homeButtonAction(_ sender: Any) {
        menuView.isHidden = true
        if segmentController.selectedSegmentIndex == 0 {
            dashboardView.isHidden = false
            profileView.isHidden = true
        } else if segmentController.selectedSegmentIndex == 1 {
            dashboardView.isHidden = true
            profileView.isHidden = false
        }
    }
    
    @IBAction func notificationButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "InchargeNotifyViewController") as! InchargeNotifyViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func feedBackButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "FeedbackViewController") as! FeedbackViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func changePwAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
        
    }
    @IBAction func logOutAction(_ sender: Any) {
        AlertManager.showCustomAlert(title: "Logout", message: "Do you want to logout?", viewController: self, okButtonTitle: "Logout", cancelButtonTitle: "Cancel", okHandler: {
            for controller in self.navigationController!.viewControllers as Array {
                if controller.isKind(of: InitialViewController.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
        })
    }
    
    func getProfileAPI() {
        APIHandler().getAPIValues(type: Profile.self, apiUrl: "\(ServiceAPI.ProfileAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                    
                    self.NameLabel.text = self.pass.data?.first?.name
                    self.addressLabel.text = self.pass.data?.first?.address
                    self.userIdLabel.text = self.pass.data?.first?.userID
                    self.contactLabel.text = self.pass.data?.first?.contactNumber
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                    let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle:.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in print("JSON Error")})
                    self.present(alert,animated: true, completion: nil)
                }
            }
        }
    }
}
