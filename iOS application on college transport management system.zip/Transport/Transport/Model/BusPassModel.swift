//
//  BusPassModel.swift
//  Transport
//
//  Created by SAIL01 on 11/10/23.
//

import Foundation

// MARK: - Welcome
struct BusPassModel: Codable {
    var data: [BusPassData]?
}

// MARK: - Datum
struct BusPassData: Codable {
    var routes, bloodGroup, contactNo, date: String?

    enum CodingKeys: String, CodingKey {
        case routes
        case bloodGroup = "blood_group"
        case contactNo = "contact_no"
        case date
    }
}
