//

import Foundation

// MARK: - Welcome
struct StDayNotification: Codable {
    var data: [StdayNot]?
}

// MARK: - Datum
struct StdayNot: Codable {
    var busID, status, date, studentID: String?

    enum CodingKeys: String, CodingKey {
        case busID = "busId"
        case status, date
        case studentID = "student_id"
    }
}
