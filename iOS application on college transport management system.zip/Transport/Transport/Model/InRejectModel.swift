//


import Foundation

struct InRejectButton: Codable {
    var status, message: String?
}
