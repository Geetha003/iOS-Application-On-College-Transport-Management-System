//

import Foundation

struct DayStuRequest: Codable {
    var status, message: String?
}
