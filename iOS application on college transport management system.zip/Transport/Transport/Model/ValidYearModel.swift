//

import Foundation

// MARK: - Welcome
struct ValidYear: Codable {
    var data: [validyear]?
}

// MARK: - Datum
struct validyear: Codable {
    var date: String?
}
