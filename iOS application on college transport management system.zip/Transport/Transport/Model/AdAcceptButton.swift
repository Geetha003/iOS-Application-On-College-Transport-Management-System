//

import Foundation

struct AdAcceptButton: Codable {
    var status, message: String?
}
