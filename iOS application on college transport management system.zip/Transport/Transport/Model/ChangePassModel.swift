//
//  ChangePassModel.swift
//  Transport
//
//  Created by SAIL01 on 18/11/23.
//

import Foundation

struct changepass: Codable {
    var status, message: String?
}
