//
//  loginpage.swift
//  Transport
//
//  Created by SAIL on 07/10/23.
//

import Foundation

// MARK: - Welcome
struct LoginModel: Codable {
    var status: Bool?
    var message: String?
    var data: [LoginData]?
}

// MARK: - Datum
struct LoginData: Codable {
    var id, name, dID, userID: String?
    var password, bloodGroup, contactNo, address: String?

    enum CodingKeys: String, CodingKey {
        case id
        case name = "Name"
        case dID = "DId"
        case userID = "user_Id"
        case password
        case bloodGroup = "blood_group"
        case contactNo = "contact_no"
        case address = "Address"
    }
}
