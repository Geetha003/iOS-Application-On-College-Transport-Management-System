//


import Foundation

// MARK: - Welcome
struct ViewList: Codable {
    var data: [viewlist]?
}

// MARK: - Datum
struct viewlist: Codable {
    var studentID, date, busID, route: String?

    enum CodingKeys: String, CodingKey {
        case studentID = "student_id"
        case date
        case busID = "bus_id"
        case route
    }
}
