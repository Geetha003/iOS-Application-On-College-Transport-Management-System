//
import Foundation

struct StuRequest: Codable {
    var status, message: String?
}
