
import Foundation

// MARK: - Welcome
struct RequestBus: Codable {
    var data: [Rebus]?
}

// MARK: - Datum
struct Rebus: Codable {
    var busID, routes: String?

    enum CodingKeys: String, CodingKey {
        case busID = "bus_id"
        case routes
    }
}
