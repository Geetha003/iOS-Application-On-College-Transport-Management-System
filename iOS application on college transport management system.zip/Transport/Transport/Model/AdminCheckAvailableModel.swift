
import Foundation

// MARK: - Welcome
struct CheckAvailable: Codable {
    var data: [chavl]?
}

// MARK: - Datum
struct chavl: Codable {
    var totalSeats, availableSeats, occupiedSeats: Int?
    var driverName: String?
    var driverContact: Int?

    enum CodingKeys: String, CodingKey {
        case totalSeats = "total_seats"
        case availableSeats = "available_seats"
        case occupiedSeats = "occupied_seats"
        case driverName = "driver_name"
        case driverContact = "driver_contact"
    }
}
