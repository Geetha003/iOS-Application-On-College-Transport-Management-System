//


import Foundation

struct Register: Codable {
    var status, message: String?
}
