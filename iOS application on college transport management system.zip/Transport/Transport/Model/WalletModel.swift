//
//  WalletModel.swift
//  Transport
//
//  Created by Haris Madhavan on 09/12/23.
//

import Foundation

struct WalletModel: Codable {
    var data: [Wallet]?
}

// MARK: - Datum
struct Wallet: Codable {
    var userID: String?
    var amountAvailable: Int?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case amountAvailable
    }
}
