//
//  adInchargeDetails.swift
//  Transport
//
//  Created by SAIL01 on 09/10/23.
//

import Foundation

// MARK: - Welcome
struct InchargeDetails: Codable {
    var data: [IncDetails]?
}

// MARK: - Datum
struct IncDetails: Codable {
    var name, userID, busID, contactNo: String?

    enum CodingKeys: String, CodingKey {
        case name = "Name"
        case userID = "user_Id"
        case busID = "bus_id"
        case contactNo = "contact_no"
    }
}
