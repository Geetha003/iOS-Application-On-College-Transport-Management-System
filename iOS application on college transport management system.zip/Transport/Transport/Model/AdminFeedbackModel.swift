//

import Foundation

// MARK: - Welcome
struct AdminFeedback: Codable {
    var data: [feedback]?
}

// MARK: - Datum
struct feedback: Codable {
    var userID, feedbackType, description, date: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case feedbackType, description, date
    }
}
