
import Foundation

// MARK: - Welcome
struct AnnualFee: Codable {
    var data: [annualfee]?
}

// MARK: - Datum
struct annualfee: Codable {
    var type, amount: String?
}
