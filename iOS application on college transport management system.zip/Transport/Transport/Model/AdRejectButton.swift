//

import Foundation

struct AdRejectButton: Codable {
    var status, message: String?
}
