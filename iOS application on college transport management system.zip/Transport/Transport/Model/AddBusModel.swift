//
//  AddBus.swift
//  Transport
//
//  Created by SAIL01 on 13/10/23.
//

import Foundation

struct AddBus: Codable {
    var status, message: String?
}
