//

import Foundation

// MARK: - Welcome
struct Profile: Codable {
    var data: [Prof]?
}

// MARK: - Datum
struct Prof: Codable {
    var name, userID, bloodGroup, contactNumber: String?
    var address: String?

    enum CodingKeys: String, CodingKey {
        case name
        case userID = "user_id"
        case bloodGroup, contactNumber, address
    }
}
