
import Foundation

struct InAcceptButton: Codable {
    var status, message: String?
}
