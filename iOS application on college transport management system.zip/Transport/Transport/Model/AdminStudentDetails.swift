//
//  adStudentDetails.swift
//  Transport
//
//  Created by SAIL on 07/10/23.
//


import Foundation

// MARK: - Welcome
struct StudentsDetails: Codable {
    var data: [StuDetails]?
}

// MARK: - Datum
struct StuDetails: Codable {
    var name, userID, busID, routes: String?

    enum CodingKeys: String, CodingKey {
        case name = "Name"
        case userID = "user_Id"
        case busID = "busId"
        case routes
    }
}
