
import Foundation

// MARK: - Welcome
struct StudentNotification: Codable {
    var data: [StNot]?
}

// MARK: - Datum
struct StNot: Codable {
    var busID, status, date, studentID: String?

    enum CodingKeys: String, CodingKey {
        case busID = "busId"
        case status, date
        case studentID = "student_id"
    }
}
