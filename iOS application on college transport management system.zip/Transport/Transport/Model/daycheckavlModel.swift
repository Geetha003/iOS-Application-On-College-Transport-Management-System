//

import Foundation

// MARK: - Welcome
struct DayCheckAvailable: Codable {
    var data: [daycheckavl]?
}

// MARK: - Datum
struct daycheckavl: Codable {
    var busID, routes: String?
    var totalSeats, availableSeats, occupiedSeats: Int?
    var driverName: String?

    enum CodingKeys: String, CodingKey {
        case busID = "bus_id"
        case routes
        case totalSeats = "total_seats"
        case availableSeats = "available_seats"
        case occupiedSeats = "occupied_seats"
        case driverName = "driver_name"
    }
}
