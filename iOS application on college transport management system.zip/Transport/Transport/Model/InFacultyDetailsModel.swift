//

import Foundation

//// MARK: - Welcome
//struct InFacultyDetails: Codable {
//    var data: [Facdetails]?
//}
//
//// MARK: - Datum
//struct Facdetails: Codable {
//    var userID, name, busID, contactNo: String?
//   
//    enum CodingKeys: String, CodingKey {
//        case userID = "user_id"
//        case name = "Name"
//        case busID = "bus_id"
//        case contactNo = "contact_no"
//    }
//}

// MARK: - Welcome
struct InFacultyDetails: Codable {
    var data: [Facdetails]?
}

// MARK: - Datum
struct Facdetails: Codable {
    var userID, name, busID: String?
    var contactNo: Int?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name
        case busID = "bus_id"
        case contactNo = "contact_no"
    }
}
