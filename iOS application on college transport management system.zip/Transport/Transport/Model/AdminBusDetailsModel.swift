//
//  adBusDetails.swift
//  Transport
//
//  Created by SAIL01 on 09/10/23.
//

import Foundation

// MARK: - Welcome
struct BusDetails: Codable {
    let data: [busdetails]?
}

// MARK: - Datum
struct busdetails: Codable {
    var busID, routes: String?

    enum CodingKeys: String, CodingKey {
        case busID = "bus_id"
        case routes
    }
}

