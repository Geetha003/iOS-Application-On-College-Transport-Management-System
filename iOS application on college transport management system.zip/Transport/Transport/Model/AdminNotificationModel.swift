//
//
import Foundation

//// MARK: - Welcome
//struct NotificationDetails: Codable {
//    var data: [NotDetails]?
//}
//
//// MARK: - Datum
//struct NotDetails: Codable {
//    var studentID, busID, status, date: String?
//
//    enum CodingKeys: String, CodingKey {
//        case studentID = "student_id"
//        case busID = "busId"
//        case status, date
//    }
//}

struct NotificationDetails: Codable {
    var data: [NotDetails]?
}

// MARK: - Datum
struct NotDetails: Codable {
    var studentID, busID, status, date: String?
    var availableSeats: String?

    enum CodingKeys: String, CodingKey {
        case studentID = "student_id"
        case busID = "busId"
        case status, date
        case availableSeats = "available_seats"
    }
}
