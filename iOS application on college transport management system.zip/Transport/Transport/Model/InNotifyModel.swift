//

import Foundation

// MARK: - Welcome
struct InNotifications: Codable {
    var data: [InNot]?
}

// MARK: - Datum
struct InNot: Codable {
    var busID, userID, name, date: String?

    enum CodingKeys: String, CodingKey {
        case busID = "bus_id"
        case userID = "user_id"
        case name, date
    }
}
