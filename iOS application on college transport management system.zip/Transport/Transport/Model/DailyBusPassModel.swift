//

import Foundation

// MARK: - Welcome
struct DailyBusPass: Codable {
    var data: [DBusPass]?
}

// MARK: - Datum
struct DBusPass: Codable {
    var routes, bloodGroup, contactNo, date: String?

    enum CodingKeys: String, CodingKey {
        case routes
        case bloodGroup = "blood_group"
        case contactNo = "contact_no"
        case date
    }
}
