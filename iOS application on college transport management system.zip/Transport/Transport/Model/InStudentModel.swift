
import Foundation

// MARK: - Welcome
struct InStudentDetails: Codable {
    var data: [InStu]?
}

// MARK: - Datum
struct InStu: Codable {
    var userID, name, busID, routes: String?

    enum CodingKeys: String, CodingKey {
        case userID = "user_id"
        case name
        case busID = "bus_id"
        case routes
    }
}
