//

import Foundation

struct AddFeedback: Codable {
    var status, message: String?
}
