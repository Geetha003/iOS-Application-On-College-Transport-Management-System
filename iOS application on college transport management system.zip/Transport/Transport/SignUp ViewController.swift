//
//  ViewController.swift
//  Transport
//
//  Created by SAIL on 19/09/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    
    @IBOutlet weak var designationTextField: UITextField!
    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var AddressTextField: UITextField!
    @IBOutlet weak var bloodgroupTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    

    @IBAction func signupButtonAction(_ sender: Any) {
        RegistrationAPI()
    }
    
    func RegistrationAPI() {
        let formData: [String: String] = [
            "user_Id": userIdTextField.text ?? "",
            "Name": NameTextField.text ?? "",
            "password": PasswordTextField.text ?? "",
            "Designation": designationTextField.text ?? "",
            "contact_no": numberTextField.text ?? "",
            "Address": AddressTextField.text ?? "",
            "blood_group": bloodgroupTextField.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: Register.self, apiUrl: Constants.serviceType.RegisterURL.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                   print(formData)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}

