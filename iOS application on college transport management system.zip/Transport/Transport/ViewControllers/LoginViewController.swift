//
//  TransporterLoginViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 28/09/23.
//

import UIKit
class LoginViewController: UIViewController {
    
    @IBOutlet weak var userIdTextField: UITextField! {
        didSet {
            userIdTextField.tintColor = .black
            userIdTextField.setIcon(UIImage(imageLiteralResourceName: "user"))
            userIdTextField.attributedPlaceholder = NSAttributedString(string: "User Id", attributes: [NSAttributedString.Key.foregroundColor : UIColor.black])
        }
    }
    @IBOutlet weak var passwordTextField: UITextField! {
        didSet {
            passwordTextField.tintColor = .black
            passwordTextField.setIcon(UIImage(imageLiteralResourceName: "password"))
            passwordTextField.attributedPlaceholder = NSAttributedString(string: "Password", attributes: [NSAttributedString.Key.foregroundColor : UIColor.black])
            passwordTextField.isSecureTextEntry = true
        }
    }
    
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    
    let border = Border()
    
    var apiURL = String()
    var login: LoginModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        loginButton.layer.cornerRadius = 20
        signUpButton.isHidden = true
        if UserDefaultsManager.shared.getKey() == "admin" {
            signUpButton.isHidden = false
        }
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func signup(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as!
        SignUpViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
       // apiURL = "http://172.17.57.101//trspt1/login_ios.php?userId=\(userIdTextField.text ?? "")&pass=\(passwordTextField.text ?? "")"
        
        if userIdTextField.text == "" && passwordTextField.text == "" {
            let alert = UIAlertController(title: "Field is empty", message: "Please enter UserId / Password", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
        } else {
            fetchLoginAPI()
        }
    }
    
    func fetchLoginAPI() {
        APIHandler.shared.getAPIValues(type: LoginModel.self, apiUrl: "\(ServiceAPI.loginURL)userId=\(userIdTextField.text ?? "")&pass=\(passwordTextField.text ?? "")", method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.login = data
                DispatchQueue.main.async {
                    if self.userIdTextField.text != self.login.data?.first?.userID {
                        let alert = UIAlertController(title: "Alert", message: "Incorrect UserID or Password", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
                        if self.login.data?.first?.dID == "1" {
                            UserDefaultsManager.shared.saveUserProfile("1")
                            UserDefaultsManager.shared.saveUserId(self.userIdTextField.text ?? "")
                            let storyboard = UIStoryboard(name: "AdminStoryboard", bundle: nil)
                            let vc = storyboard.instantiateViewController(withIdentifier: "AdminHomeViewController") as! AdminHomeViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.login.data?.first?.dID == "2" {
                            self.signUpButton.isHidden = true
                            UserDefaultsManager.shared.saveUserProfile("2")
                            UserDefaultsManager.shared.saveUserId(self.userIdTextField.text ?? "")
                            let storyboard = UIStoryboard(name: "BusInchargeStoryboard", bundle: nil)
                            let vc = storyboard.instantiateViewController(withIdentifier: "InchargeHomeViewController") as! InchargeHomeViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.login.data?.first?.dID == "3" {
                            UserDefaultsManager.shared.saveUserProfile("3")
                            UserDefaultsManager.shared.saveUserId(self.userIdTextField.text ?? "")
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "QuickRideHomeViewController") as! QuickRideHomeViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        } else if self.login.data?.first?.dID == "4" {
                            UserDefaultsManager.shared.saveUserProfile("4")
                            UserDefaultsManager.shared.saveUserId(self.userIdTextField.text ?? "")
                            UserDefaultsManager.shared.saveUserId(self.login.data?.first?.userID ?? "")
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "PassengerHomeViewController") as! PassengerHomeViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension UITextField {
    func setIcon(_ image: UIImage) {
        let iconView = UIImageView(frame:
                                    CGRect(x: 10, y: 5, width: 20, height: 20))
        iconView.image = image
        let iconContainerView: UIView = UIView(frame:
                                                CGRect(x: 20, y: 0, width: 30, height: 30))
        iconContainerView.addSubview(iconView)
        leftView = iconContainerView
        leftViewMode = .always
    }
}

