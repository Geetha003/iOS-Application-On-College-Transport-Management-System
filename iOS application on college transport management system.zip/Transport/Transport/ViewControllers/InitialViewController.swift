//
//  InitialViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class InitialViewController: UIViewController {
    
    @IBOutlet weak var startButton: UIButton!
    
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        border.applyShadowButton(to: startButton)
        startButton.layer.cornerRadius = 20
    }
    
    @IBAction func startButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "SelectLoginViewController") as! SelectLoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
}
