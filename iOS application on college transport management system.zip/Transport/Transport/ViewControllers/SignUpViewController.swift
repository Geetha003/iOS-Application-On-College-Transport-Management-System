//
//  SignUpViewController.swift
//  Transport
//
//  Created by SAIL01 on 14/10/23.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var designationTextField: UITextField!
    @IBOutlet weak var numberTextField: UITextField!
    @IBOutlet weak var AddressTextField: UITextField!
    @IBOutlet weak var bloodgroupTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var signup: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.PasswordTextField.isSecureTextEntry = true
    }
   
    @IBAction func backAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func signUpAction(_ sender: Any) {
        if NameTextField.text?.isEmpty == true || designationTextField.text?.isEmpty == true || numberTextField.text?.isEmpty == true || AddressTextField.text?.isEmpty == true || bloodgroupTextField.text?.isEmpty == true || PasswordTextField.text?.isEmpty == true || userIdTextField.text?.isEmpty == true {
            AlertManager.showAlert(title: "Alert", message: "Please enter all the values", viewController: self)
        } else {
            RegistrationAPI()
        }
        
    }
    
    func RegistrationAPI() {
        let formData: [String: String] = [
            "user_Id": userIdTextField.text ?? "",
            "Name": NameTextField.text ?? "",
            "password": PasswordTextField.text ?? "",
            "Designation": designationTextField.text ?? "",
            "contact_no": numberTextField.text ?? "",
            "Address": AddressTextField.text ?? "",
            "blood_group": bloodgroupTextField.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: Register.self, apiUrl:  ServiceAPI.RegisterURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
//                    AlertManager.showAutoPopAlert(title: "\(response.status ?? "")", message: "\(response.message)", viewController: self, navigationController: self.navigationController!, duration: 5.0)
                    AlertManager.showAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self, completionHandler: nil)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }

}
