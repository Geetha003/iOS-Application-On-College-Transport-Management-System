//
//  SelectLoginViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class SelectLoginViewController: UIViewController {
    
    @IBOutlet weak var BusInchargeView: UIView!
    @IBOutlet weak var TransportetView: UIView!
    @IBOutlet weak var AdminView: UIView!
    
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        border.viewBorder(to: BusInchargeView)
        border.viewBorder(to: TransportetView)
        border.viewBorder(to: AdminView)
        
        let tapGestureBusIncharge = UITapGestureRecognizer(target: self, action: #selector(busInchargeTap(_:)))
        BusInchargeView.addGestureRecognizer(tapGestureBusIncharge)
        BusInchargeView.isUserInteractionEnabled = true
        
        let tapGestureTransporter = UITapGestureRecognizer(target: self, action: #selector(transporterTap(_:)))
        TransportetView.addGestureRecognizer(tapGestureTransporter)
        TransportetView.isUserInteractionEnabled = true
        
        let tapGestureAdmin = UITapGestureRecognizer(target: self, action: #selector(adminTap(_:)))
        AdminView.addGestureRecognizer(tapGestureAdmin)
        AdminView.isUserInteractionEnabled = true
    }
    
    @objc func busInchargeTap(_ sender: UITapGestureRecognizer) {
        UserDefaultsManager.shared.saveKey("")
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func transporterTap(_ sender: UITapGestureRecognizer) {
        UserDefaultsManager.shared.saveKey("")
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "PassengerViewController") as! PassengerViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func adminTap(_ sender: UITapGestureRecognizer) {
        UserDefaultsManager.shared.saveKey("admin")
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
