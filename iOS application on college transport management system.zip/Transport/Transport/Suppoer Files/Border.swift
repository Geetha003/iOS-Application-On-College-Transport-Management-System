//
//  Border.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import Foundation
import UIKit

var border = Border()

class Border {
    
    func viewBorder(to view: UIView) {
        view.layer.cornerRadius = 20
        view.layer.borderColor = UIColor.black.cgColor
        view.layer.borderWidth = 0.5
    }
    
    func imageBorder(to imageView: UIImageView) {
        imageView.layer.cornerRadius = 5
        imageView.layer.borderColor = UIColor.black.cgColor
        imageView.layer.borderWidth = 0.5
    }
    
    func textFieldBorder(to textField: UITextField) {
        textField.layer.cornerRadius = 10
//        textField.layer.borderColor = UIColor.black.cgColor
//        textField.layer.borderWidth = 0.5
    }
    
    func applyShadowView(to view: UIView) {
        view.layer.cornerRadius = 20
        view.layer.borderColor = UIColor.white.cgColor
        view.layer.masksToBounds = false
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.3
        view.layer.shadowOffset = CGSize(width: 0, height: 4)
        view.layer.shadowRadius = 2.0
    }
    
    func applyShadowButton(to button: UIButton) {
        button.layer.borderColor = UIColor.white.cgColor
        button.layer.masksToBounds = false
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.3
        button.layer.shadowOffset = CGSize(width: 0, height: 4)
        button.layer.shadowRadius = 2.0
    }
}
