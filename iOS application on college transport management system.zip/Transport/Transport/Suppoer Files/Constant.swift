//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit

//public class Constants {
//
//    static var shared = Constants()
//
//    var userId : String? {
//        return UserDefaultsManager.shared.getUserID()
//    }
//    var boardingPoint : String? {
//        return UserDefaultsManager.shared.getBoardingPoint()
//    }
//
//    var busId: String? = nil
//
//    var listBusId : String? {
//        return UserDefaultsManager.shared.getBusID()
//    }
//
//    enum serviceType: String {
//        case loginURL = "http://172.17.50.128//trspt1/login_ios.php?userId=ad123&pass=hari@123"
//
//        static var BusPassAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/st_daybuspass.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var DayCheckAvailableAPI : String {
//            if let boardingPoint = Constants().boardingPoint {
//                return "http://172.17.57.101//trspt1/st_daycheckavailable.php?routes=\(boardingPoint)"
//            } else {
//                return ""
//            }
//        }
//        static var ValidYearAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/st_date.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var StBusPassAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/st_buspass.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var ProfileAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/profile.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var checkavailableAPI: String {
//                if let busID = shared.busId {
//                    return "http://172.17.57.101/trspt1/ad_checkavailable.php?bus_id=\(busID)"
//                } else {
//                    return ""
//                }
//            }
//        static var viewListAPI: String {
//                if let busID = shared.listBusId {
//                    return "http://172.17.57.101/trspt1/ad_approvalist.php?bus_id=\(busID)"
//                } else {
//                    return ""
//                }
//            }
//
//        static var InStudentDetailsAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/in_student_details.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var InFacultyDetailsAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/in_faculty_details.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var InNotificationDetailsAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/in_notification.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var AnnualFeeAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101//trspt1/st_annualfee.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var StudentNotificationAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101/trspt1/st_notification.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//        static var DayStudentNotificationAPI : String {
//            if let userID = Constants().userId {
//                return "http://172.17.57.101/trspt1/st_day_notification.php?userId=\(userID)"
//            } else {
//                return ""
//            }
//        }
//
//
//        case adminLoginURL = "http://172.17.57.101//trspt1/login_ios.php?userId=ad123&pass=hari@12"
//        case adStudentdetailsURL =
//            "http://172.17.57.101//trspt1/ad_student_details.php"
//        case adInchargedetailsURL =
//            "http://172.17.57.101//trspt1/ad_incharge_details.php"
//        case adBusdetailsURL =
//            "http://172.17.57.101//trspt1/ad_bus_details.php"
//        case adNotificationsURL =
//            "http://172.17.57.101//trspt1/ad_notification.php"
//        case adCheckAvailableURL =
//            "http://172.17.57.101/trspt1/ad_checkavailable.php?bus_id=b101"
//        case stRequestBusURL =
//            "http://172.17.57.101/trspt1/st_busdetails.php"
//        case addBusDetailsURL = "http://172.17.57.101/trspt1/ad_addbus.php"
//        case addFeedbackURL = "http://172.17.57.101/trspt1/feedback.php"
//        case RegisterURL = "http://172.17.57.101/trspt1/register.php"
//        case adFeedbackdetailsURL =
//            "http://172.17.57.101//trspt1/ad_feedback.php"
//        case InAcceptButtonURL = "http://172.17.57.101/trspt1/in_accept_button.php"
//        case InRejectButtonURL = "http://172.17.57.101/trspt1/in_reject_button.php"
//        case AdAcceptButtonURL = "http://172.17.57.101/trspt1/ad_updateaccept.php"
//        case AdRejectButtonURL = "http://172.17.57.101/trspt1/ad_reject_button.php"
//        case studentRequestURL = "http://172.17.57.101/trspt1/st_requestbus.php"
//        case studentDayRequestURL = "http://172.17.57.101/trspt1/st_dayrequest.php"
//
//    }
//
//    static let loginUrl: serviceType = .loginURL
//    static let adminLoginUrL: serviceType = .adminLoginURL
//    static let adStudentdetailsUrL: serviceType = .adStudentdetailsURL
//    static let adInchargedetailsUrL: serviceType = .adInchargedetailsURL
//    static let adBusdetailsUrL: serviceType = .adBusdetailsURL
//    static let adNotificationsUrL: serviceType = .adNotificationsURL
//    static let adCheckAvailableUrL: serviceType = .adCheckAvailableURL
//    static let stRequestBusUrL: serviceType = .stRequestBusURL
//    static let addBusUrL: serviceType = .addBusDetailsURL
//    static let addfeedUrL: serviceType = .addFeedbackURL
//    static let RegisterUrL: serviceType = .RegisterURL
//    static let adFeedbackdetailsUrL: serviceType = .adFeedbackdetailsURL
//    static let InAcceptButtonUrL: serviceType = .InAcceptButtonURL
//    static let InRejectButtonUrL: serviceType = .InRejectButtonURL
//    static let AdAcceptButtonUrL: serviceType = .AdAcceptButtonURL
//    static let AdRejectButtonUrL: serviceType = .AdRejectButtonURL
//    static let studentRequestUrL: serviceType = .studentRequestURL
//    static let studentDayRequestUrL: serviceType = .studentDayRequestURL
//
//}

struct ServiceAPI {
    
    static let baseURL = "http://172.20.10.3/"
    static let loginURL = baseURL+"trspt1/login_ios.php?" // userId=ad123&pass=hari@123
    static let BusPassAPI = baseURL+"trspt1/st_daybuspass.php?" //userId=f1223
    static let DayCheckAvailableAPI = baseURL+"trspt1/st_daycheckavailable.php?" //routes=tambaram
    static let ValidYearAPI = baseURL+"trspt1/st_date.php?" //userId=f1223
    static let StBusPassAPI = baseURL+"trspt1/st_buspass.php?" //userId=f1223
    static let ProfileAPI = baseURL+"trspt1/profile.php?" //userId=f1223
    static let checkavailableAPI = baseURL+"trspt1/ad_checkavailable.php?" //bus_id=b101
    static let viewListAPI = baseURL+"trspt1/ad_approvalist.php?" //bus_id=b101
    static let InStudentDetailsAPI = baseURL+"trspt1/in_student_details.php?" //userId=f1223
    static let InFacultyDetailsAPI = baseURL+"trspt1/in_faculty_details.php?" //userId=f1223
    static let InNotificationDetailsAPI = baseURL+"trspt1/in_notification.php?" //userId=f1223
    static let AnnualFeeAPI = baseURL+"trspt1/st_annualfee.php?" //userId=f1223
    static let StudentNotificationAPI = baseURL+"trspt1/st_notification.php?" //userId=f1223
    static let DayStudentNotificationAPI = baseURL+"trspt1/st_day_notification.php?" //userId=f1223
    static let adStudentdetailsURL = baseURL+"trspt1/ad_student_details.php?"
    static let adInchargedetailsURL = baseURL+"trspt1/ad_incharge_details.php?"
    static let adBusdetailsURL = baseURL+"trspt1/ad_bus_details.php?"
    static let adNotificationsURL = baseURL+"trspt1/admin_notification.php?"
    static let adCheckAvailableURL = baseURL+"trspt1/ad_checkavailable.php?"
    static let stRequestBusURL = baseURL+"trspt1/st_busdetails.php?"
    static let addBusDetailsURL = baseURL+"trspt1/ad_addbus.php?"
    static let addFeedbackURL = baseURL+"trspt1/feedback.php?"
    static let RegisterURL = baseURL+"trspt1/register.php?"
    static let adFeedbackdetailsURL = baseURL+"trspt1/ad_feedback.php?"
    static let InAcceptButtonURL = baseURL+"trspt1/in_accept_button.php?"
    static let InRejectButtonURL = baseURL+"trspt1/in_reject_button.php?"
    static let AdAcceptButtonURL = baseURL+"trspt1/ad_updateaccept.php?"
    static let AdRejectButtonURL = baseURL+"trspt1/ad_reject_button.php?"
    static let studentRequestURL = baseURL+"trspt1/st_requestbus.php?"
    static let studentDayRequestURL = baseURL+"trspt1/st_dayrequest.php?"
    static let changepasswordURL = baseURL+"trspt1/changepassword.php?"
    static let WalletAmountURL = baseURL+"trspt1/amountavailable.php?"
    
}
