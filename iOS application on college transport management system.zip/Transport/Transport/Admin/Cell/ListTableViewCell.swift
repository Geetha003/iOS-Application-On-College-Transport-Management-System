//
//  ListTableViewCell.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class ListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var approveButton: UIButton!
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var studIdLabel: UILabel!
    @IBOutlet weak var busIdLabel: UILabel!
    @IBOutlet weak var availableSeatsLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
