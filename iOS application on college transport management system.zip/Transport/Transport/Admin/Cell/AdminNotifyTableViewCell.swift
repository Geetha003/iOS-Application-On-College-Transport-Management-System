//
//  AdminNotifyTableViewCell.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class AdminNotifyTableViewCell: UITableViewCell {
    
    @IBOutlet weak var bellImage: UIImageView!
    @IBOutlet weak var stdIdLabel: UILabel!
    @IBOutlet weak var busIdLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var dteLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
