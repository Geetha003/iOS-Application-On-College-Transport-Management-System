//
//  InchargeViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class InchargeViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var InchargeTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var details: InchargeDetails!
    var Details: InFacultyDetails!
    var filtered: [IncDetails]!
    var Infiltered: [Facdetails]!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    var searching : Bool = false
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.InchargeTableView.delegate = self
        self.InchargeTableView.dataSource = self
        
        self.searchBar.delegate = self
        
        topView.layer.cornerRadius = 5
        searchBar.searchTextField.backgroundColor = .white
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchInchargeAPI()
        fetchInfacultyAPI()
    }

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    func fetchInchargeAPI() {
        APIHandler.shared.getAPIValues(type: InchargeDetails.self, apiUrl: ServiceAPI.adInchargedetailsURL,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.details = data
                DispatchQueue.main.async {
                    self.InchargeTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
        
                }
            
            }
        }
    }
    func fetchInfacultyAPI() {
        APIHandler.shared.getAPIValues(type: InFacultyDetails.self, apiUrl: "\(ServiceAPI.InFacultyDetailsAPI)&userId=\(savedUserId)",method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.Details = data
                DispatchQueue.main.async {
                    self.InchargeTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                
                }
            
            }
        }
    }
}

extension InchargeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if UserDefaultsManager.shared.getUserProfile() == "1" {
            if searching {
                return self.filtered.count
            } else {
                return self.details?.data?.count ?? 1
            }
        } else if UserDefaultsManager.shared.getUserProfile() == "2" {
            if searching {
                return self.Infiltered.count
            } else {
                return self.Details?.data?.count ?? 1
            }
        } else {
            return 1
    }
}
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InchargeTableViewCell", for: indexPath) as! InchargeTableViewCell
        
        if UserDefaultsManager.shared.getUserProfile() == "1"{
            if let detail = self.details?.data?[indexPath.row] {
                cell.idLabel.text = ":     \(detail.userID ?? "")"
                cell.namwLabel.text = ":     \(detail.name ?? "")"
                cell.busIdLabel.text = ":     \(detail.busID ?? "")"
                cell.contactLabel.text = ":     \(detail.contactNo ?? "")"
            } else {
                cell.idLabel.text = "No data"
                cell.namwLabel.text = ""
                cell.busIdLabel.text = ""
                cell.contactLabel.text = ""
            }
        } else if UserDefaultsManager.shared.getUserProfile() == "2" {
            if let detail = self.Details?.data?[indexPath.row] {
                cell.idLabel.text = ":     \(detail.userID ?? "")"
                cell.namwLabel.text = ":     \(detail.name ?? "")"
                cell.busIdLabel.text = ":     \(detail.busID ?? "")"
                cell.contactLabel.text = ":     \(detail.contactNo ?? 0)"
            } else {
                cell.idLabel.text = "No data"
                cell.namwLabel.text = ""
                cell.busIdLabel.text = ""
                cell.contactLabel.text = ""
            }
        }
        
        border.applyShadowView(to: cell.cellView)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
}

extension InchargeViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if UserDefaultsManager.shared.getUserProfile() == "1" {
            if searchText.isEmpty {
                searching = false
                filtered.removeAll()
            } else {
                searching = true
                filtered = details.data?.filter{$0.name?.range(of: searchText, options: .caseInsensitive) != nil}
            }
            InchargeTableView.reloadData()
        } else if UserDefaultsManager.shared.getUserProfile() == "2" {
            if searchText.isEmpty {
                searching = false
                Infiltered.removeAll()
            } else {
                searching = true
                Infiltered = Details.data?.filter{$0.name?.range(of: searchText, options: .caseInsensitive) != nil}
            }
            InchargeTableView.reloadData()
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
    }
}
