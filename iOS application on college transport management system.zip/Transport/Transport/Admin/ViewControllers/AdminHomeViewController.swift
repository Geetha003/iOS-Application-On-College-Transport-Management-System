//
//  AdminHomeViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 26/09/23.
//

import UIKit

class AdminHomeViewController: UIViewController, UIViewControllerTransitioningDelegate {
    
    @IBOutlet weak var logOutButton: UIButton!
    @IBOutlet weak var busDetailsView: UIView!
    @IBOutlet weak var busDetailsImage: UIImageView!
    @IBOutlet weak var addBusView: UIView!
    @IBOutlet weak var addBusImage: UIImageView!
    @IBOutlet weak var studentDetailsView: UIView!
    @IBOutlet weak var studentDetailsImage: UIImageView!
    @IBOutlet weak var busInchargeView: UIView!
    @IBOutlet weak var busInchargeImage: UIImageView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    @IBOutlet weak var feedbackImage: UIImageView!
    @IBOutlet weak var feedbackView: UIView!
    @IBOutlet weak var dashboardView: UIView!
    @IBOutlet weak var notificationsView: UIView!
    @IBOutlet weak var AdminNotifyTableView: UITableView!
    
//    var apiData: welcome!
    var details: NotificationDetails!
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.AdminNotifyTableView.delegate = self
        self.AdminNotifyTableView.dataSource = self
        
        dashboardView.isHidden = false
        notificationsView.isHidden = true
        
        border.viewBorder(to: busDetailsView)
        border.viewBorder(to: addBusView)
        border.viewBorder(to: studentDetailsView)
        border.viewBorder(to: busInchargeView)
        border.viewBorder(to: feedbackView)
        
        border.imageBorder(to: busDetailsImage)
        border.imageBorder(to: addBusImage)
        border.imageBorder(to: studentDetailsImage)
        border.imageBorder(to: busInchargeImage)
        border.imageBorder(to: feedbackImage)
        
        let tapGestureBusDetails = UITapGestureRecognizer(target: self, action: #selector(busDetailsTap(_:)))
        busDetailsView.addGestureRecognizer(tapGestureBusDetails)
        busDetailsView.isUserInteractionEnabled = true
        
        let tapGestureAddBus = UITapGestureRecognizer(target: self, action: #selector(addBusTap(_:)))
        addBusView.addGestureRecognizer(tapGestureAddBus)
        addBusView.isUserInteractionEnabled = true
        
        let tapGestureStudent = UITapGestureRecognizer(target: self, action: #selector(studentDetailsTap(_:)))
        studentDetailsView.addGestureRecognizer(tapGestureStudent)
        studentDetailsView.isUserInteractionEnabled = true
        
        let tapGestureIncharge = UITapGestureRecognizer(target: self, action: #selector(inchargeDetailsTap(_:)))
        busInchargeView.addGestureRecognizer(tapGestureIncharge)
        busInchargeView.isUserInteractionEnabled = true
        
        let tapGestureFeedback = UITapGestureRecognizer(target: self, action: #selector(feedbackdetailsTap(_:)))
        feedbackView.addGestureRecognizer(tapGestureFeedback)
        feedbackView.isUserInteractionEnabled = true
    }
    
    @objc func busDetailsTap(_ sender: UITapGestureRecognizer) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "BusDetailsViewController") as! BusDetailsViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @objc func addBusTap(_ sender: UITapGestureRecognizer) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddBusViewController") as! AddBusViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func studentDetailsTap(_ sender: UITapGestureRecognizer) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "StudentDetailsViewController") as! StudentDetailsViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func inchargeDetailsTap(_ sender: UITapGestureRecognizer) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "InchargeViewController") as! InchargeViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func feedbackdetailsTap(_ sender: UITapGestureRecognizer) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AdFeedbackViewController") as! AdFeedbackViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            dashboardView.isHidden = false
            notificationsView.isHidden = true
        case 1:
            dashboardView.isHidden = true
            notificationsView.isHidden = false
        default:
            break
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchNotificationsAPI()
    }
    
    
    @IBAction func logOutButtonAction(_ sender: Any) {
        AlertManager.showCustomAlert(title: "Logout", message: "Do you want to logout?", viewController: self, okButtonTitle: "Logout", cancelButtonTitle: "Cancel", okHandler: {
            for controller in self.navigationController!.viewControllers as Array {
                if controller.isKind(of: InitialViewController.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
        })
    }
    func fetchNotificationsAPI() {
        APIHandler.shared.getAPIValues(type: NotificationDetails.self, apiUrl: ServiceAPI.adNotificationsURL ,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.details = data
                DispatchQueue.main.async {
                    self.AdminNotifyTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
            
            }
        }
    }
}

extension AdminHomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.details?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as! ListTableViewCell
        
        cell.approveButton.layer.cornerRadius = 5
        cell.rejectButton.layer.cornerRadius = 5
        
        cell.approveButton.tag = indexPath.row
        cell.approveButton.addTarget(self, action: #selector(approveButton(sender:)), for: .touchUpInside)
        
        cell.rejectButton.tag = indexPath.row
        cell.rejectButton.addTarget(self, action: #selector(rejectButton(sender:)), for: .touchUpInside)
        
        border.applyShadowView(to: cell.cellView)
        if let detail = self.details?.data?[indexPath.row] {
            cell.studIdLabel.text = "Student Id: \(detail.studentID ?? "")"
            cell.busIdLabel.text = " Bus Id: \(detail.busID ?? "")"
            cell.availableSeatsLabel.text = "Available seats: \(detail.availableSeats ?? "")"
        } else {
            cell.studIdLabel.text = "No data"
            cell.busIdLabel.text = ""
            cell.availableSeatsLabel.text = ""
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    @objc func approveButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let busId = self.details.data?[rowToRemove].busID else {
            return
        }
        guard let userId = self.details.data?[rowToRemove].studentID else {
            return
        }
        guard let date = self.details.data?[rowToRemove].date else {
            return
        }
    if let busIndex = self.details.data?.firstIndex(where: { $0.busID == busId }),
           let userIndex = self.details.data?.firstIndex(where: { $0.studentID == userId }),
       let dateIndex = self.details.data?.firstIndex(where: { $0.date == date }){
            
            if userIndex == busIndex && userIndex == dateIndex{
                // Remove the item at the common index
                self.details.data?.remove(at: userIndex)
                self.fetchNotificationsAPI()
            }
        self.AdminNotifyTableView.reloadData()
        let formData: [String: String] = ["student_id": userId, "bus_id": busId , "date": date ]
        APIHandler().postAPIValues(type: InAcceptButton.self, apiUrl: ServiceAPI.AdAcceptButtonURL , method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    self.fetchNotificationsAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}

    @objc func rejectButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let busId = self.details.data?[rowToRemove].busID else {
            return
        }
        guard let userId = self.details.data?[rowToRemove].studentID else {
            return
        }
        guard let date = self.details.data?[rowToRemove].date else {
            return
        }
    if let busIndex = self.details.data?.firstIndex(where: { $0.busID == busId }),
           let userIndex = self.details.data?.firstIndex(where: { $0.studentID == userId }),
       let dateIndex = self.details.data?.firstIndex(where: { $0.date == date }){
            
            if userIndex == busIndex && userIndex == dateIndex{
                // Remove the item at the common index
                self.details.data?.remove(at: userIndex)
                self.fetchNotificationsAPI()
            }
        self.AdminNotifyTableView.reloadData()
        let formData: [String: String] = ["student_id": userId, "bus_id": busId, "date": date]
        APIHandler().postAPIValues(type: InRejectButton.self, apiUrl: ServiceAPI.AdRejectButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.fetchNotificationsAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}
    
}

