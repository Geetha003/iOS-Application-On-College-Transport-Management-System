//
//  BusDetailsViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class BusDetailsViewController: UIViewController {
    
    @IBOutlet weak var busDetailsTableView: UITableView!
    @IBOutlet weak var topView: UIView!
    
    var details: BusDetails!
    
    let border = Border()
    
    var busId: String? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

        self.busDetailsTableView.delegate = self
        self.busDetailsTableView.dataSource =  self
        
        topView.layer.cornerRadius = 5
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchBusAPI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func fetchBusAPI() {
        APIHandler.shared.getAPIValues(type: BusDetails.self, apiUrl: ServiceAPI.adBusdetailsURL ,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.details = data
                DispatchQueue.main.async {
//                    UserDefaultsManager.shared.saveBusId(self.details.data?.first?.busID ?? "")
                    self.busDetailsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            
            }
        }
    }
    
    
    
}

extension BusDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.details?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BusDetailsTableViewCell", for: indexPath) as! BusDetailsTableViewCell
    
        if let detail = self.details?.data?[indexPath.row] {
//            UserDefaultsManager.shared.saveBusId(detail.busID ?? "")
            cell.idLabel.text = "Bus ID:\(detail.busID ?? "")"
            cell.routeLabel.text = "Bus Route:\(detail.routes ?? "")"
        } else {
            cell.idLabel.text = "No data"
            cell.routeLabel.text = ""
           
        }
        
        cell.availableButton.layer.cornerRadius = 5
        cell.availableButton.tag = indexPath.row
        cell.availableButton.addTarget(self, action: #selector(availableButtonAction), for: .touchUpInside)
        
        border.applyShadowView(to: cell.cellView)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    @objc func availableButtonAction(_ sender: UIButton) {
        if let detail = self.details?.data?[sender.tag] {
                let busID = detail.busID ?? ""
                
                // Set the busId in Constants
            self.busId = busID
            UserDefaultsManager.shared.saveBusId(self.busId ?? "")
                
                // Create the CheckAvailableViewController
                let storyboard = UIStoryboard(name: "AdminStoryboard", bundle: nil)
                let vc = storyboard.instantiateViewController(withIdentifier: "CheckAvailableViewController") as! CheckAvailableViewController
                
                navigationController?.pushViewController(vc, animated: true)
            }
    }
}
