//
//  AddBusViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class AddBusViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var busIdTextfield: UITextField!
    @IBOutlet weak var AvailableLabel: UITextField!
    @IBOutlet weak var TotalLabel: UITextField!
    @IBOutlet weak var OccupiedLabel: UITextField!
    @IBOutlet weak var busRouteTextField: UITextField!
    @IBOutlet weak var driverNameTextField: UITextField!
    @IBOutlet weak var contactTextField: UITextField!
    @IBOutlet weak var InchargeIdLabel: UITextField!
    @IBOutlet weak var inchargeNameTextField: UITextField!
    @IBOutlet weak var inchargeContactTextField: UITextField!
    @IBOutlet weak var addButton: UIButton!
    
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        busIdTextfield.layer.cornerRadius = 5
        busRouteTextField.layer.cornerRadius = 5
        driverNameTextField.layer.cornerRadius = 5
        contactTextField.layer.cornerRadius = 5
        inchargeNameTextField.layer.cornerRadius = 5
        inchargeContactTextField.layer.cornerRadius = 5
        border.applyShadowButton(to: addButton)
    }
    

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        addBusAPI()
    }
    
    func addBusAPI() {
        let formData: [String: String] = [
            "busid": busIdTextfield.text ?? "",
            "bus_route": busRouteTextField.text ?? "",
            "driver_name": driverNameTextField.text ?? "",
            "driver_contact_no": contactTextField.text ?? "",
            "incharge_name": inchargeNameTextField.text ?? "",
            "incharge_mobile_no": inchargeContactTextField.text ?? "",
            "total_seats": TotalLabel.text ?? "",
            "available_seats": AvailableLabel.text ?? "",
            "occupied_seats": OccupiedLabel.text ?? "",
            "incharge_id": InchargeIdLabel.text ?? ""
        ]
        APIHandler().postAPIValues(type: AddBus.self, apiUrl: ServiceAPI.addBusDetailsURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                   print(formData)
                    AlertManager.showAutoPopAlert(title: "Success", message: "Bus Added Successfully", viewController: self, navigationController: self.navigationController!, duration: 0.2)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }

}
