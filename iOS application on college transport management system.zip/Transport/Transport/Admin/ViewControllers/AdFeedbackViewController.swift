//
//  AdFeedbackViewController.swift
//  Transport
//
//  Created by SAIL01 on 18/10/23.
//

import UIKit

class AdFeedbackViewController: UIViewController {
    var details: AdminFeedback!
    
    @IBOutlet weak var FeedbackTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.FeedbackTableView.delegate = self
        self.FeedbackTableView.dataSource = self
      
    }
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchfeedbackAPI()
    }
    func fetchfeedbackAPI() {
        APIHandler.shared.getAPIValues(type: AdminFeedback.self,  apiUrl: ServiceAPI.adFeedbackdetailsURL,method:"GET") { result in
            switch result {
            case .success(let data):
                self.details = data
                print(self.details.data ?? "")
                print(self.details.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.FeedbackTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                    let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle:.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in print("JSON Error")})
                    self.present(alert,animated: true, completion: nil)
                }
            
            }
        }
    }


}

extension AdFeedbackViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.details?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FeedbackTableViewCell", for: indexPath) as! FeedbackTableViewCell
        
        if let detail = self.details?.data?[indexPath.row] {
            cell.userIdLabel.text = ":  \(detail.userID ?? "")"
            cell.TypeLabel.text = ":  \(detail.feedbackType ?? "")"
            cell.descriptionLabel.text = ":  \(detail.description ?? "")"
          
        } else {
            cell.userIdLabel.text = "No data"
            cell.TypeLabel.text = ""
            cell.descriptionLabel.text = ""
           
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
