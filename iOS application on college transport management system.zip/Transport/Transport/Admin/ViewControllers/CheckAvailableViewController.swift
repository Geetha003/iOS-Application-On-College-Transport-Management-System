//
//  CheckAvailableViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class CheckAvailableViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var detailsView: UIView!
    @IBOutlet weak var totalSeatsLabel: UILabel!
    @IBOutlet weak var availableSeatsLabel: UILabel!
    @IBOutlet weak var occupiedSeatsLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    
    
    let border = Border()
    var check: CheckAvailable!
    var listBusId = UserDefaultsManager.shared.getBusID() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        border.applyShadowView(to: detailsView)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetchAvailablePI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func approveListButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func fetchAvailablePI() {
        APIHandler.shared.getAPIValues(type: CheckAvailable.self, apiUrl: "\(ServiceAPI.checkavailableAPI)&bus_id=\(listBusId)", method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.check = data
                DispatchQueue.main.async {
                    self.totalSeatsLabel.text = "Total Seats :\(Int(self.check.data?.first?.totalSeats ?? 0))"
                    self.availableSeatsLabel.text = "Available Seats :\(Int(self.check.data?.first?.availableSeats ?? 0))"
                    self.occupiedSeatsLabel.text = "Occupied Seats :\(Int(self.check.data?.first?.occupiedSeats ?? 0))"
                    self.NameLabel.text = "Name :\((self.check.data?.first?.driverName ?? ""))"
                    self.contactLabel.text = "Contact No :\(Int(self.check.data?.first?.driverContact ?? 0))"
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            
            }
        }
    }
    
}
