//
//  ListViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class ListViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var listTableView: UITableView!
    
    let border = Border()
    var check: ViewList!
    var accept : AdAcceptButton!
    var reject : AdRejectButton!
    var listBusId = UserDefaultsManager.shared.getBusID() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.listTableView.delegate = self
        self.listTableView.dataSource = self
        
        topView.layer.cornerRadius = 5
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetchListAPI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddBusViewController") as! AddBusViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func fetchListAPI() {
        APIHandler.shared.getAPIValues(type: ViewList.self, apiUrl: "\(ServiceAPI.viewListAPI)&bus_id=\(listBusId)",method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.check = data
                DispatchQueue.main.async {
                    self.listTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            
            }
        }
    }
}

extension ListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.check?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as! ListTableViewCell
        
        cell.approveButton.layer.cornerRadius = 5
        cell.rejectButton.layer.cornerRadius = 5
        
        cell.approveButton.tag = indexPath.row
        cell.approveButton.addTarget(self, action: #selector(approveButton(sender:)), for: .touchUpInside)
        
        cell.rejectButton.tag = indexPath.row
        cell.rejectButton.addTarget(self, action: #selector(rejectButton(sender:)), for: .touchUpInside)
        
        border.applyShadowView(to: cell.cellView)
        
//        if let check = self.check?.data?[indexPath.row] {
//            cell.idLabel.text = "Student Id:\(check.studentID ?? "")"
//            cell.routeLabel.text = "Bus Route:\(check.route ?? "")"
//        } else {
//            cell.idLabel.text = "No data"
//            cell.routeLabel.text = ""
//           
//        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    @objc func approveButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let busId = self.check.data?[rowToRemove].busID else {
            return
        }
        guard let userId = self.check.data?[rowToRemove].studentID else {
            return
        }
        guard let date = self.check.data?[rowToRemove].date else {
            return
        }
    if let busIndex = self.check.data?.firstIndex(where: { $0.busID == busId }),
           let userIndex = self.check.data?.firstIndex(where: { $0.studentID == userId }),
       let dateIndex = self.check.data?.firstIndex(where: { $0.date == date }){
            
            if userIndex == busIndex && userIndex == dateIndex{
                // Remove the item at the common index
                self.check.data?.remove(at: userIndex)
                self.fetchListAPI()
            }
        self.listTableView.reloadData()
        let formData: [String: String] = ["student_id": userId, "bus_id": busId , "date": date ]
        APIHandler().postAPIValues(type: InAcceptButton.self, apiUrl: ServiceAPI.AdAcceptButtonURL , method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    self.fetchListAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}

    @objc func rejectButton(sender: UIButton) {
        let rowToRemove = sender.tag
        guard let busId = self.check.data?[rowToRemove].busID else {
            return
        }
        guard let userId = self.check.data?[rowToRemove].studentID else {
            return
        }
        guard let date = self.check.data?[rowToRemove].date else {
            return
        }
    if let busIndex = self.check.data?.firstIndex(where: { $0.busID == busId }),
           let userIndex = self.check.data?.firstIndex(where: { $0.studentID == userId }),
       let dateIndex = self.check.data?.firstIndex(where: { $0.date == date }){
            
            if userIndex == busIndex && userIndex == dateIndex{
                // Remove the item at the common index
                self.check.data?.remove(at: userIndex)
                self.fetchListAPI()
            }
        self.listTableView.reloadData()
        let formData: [String: String] = ["student_id": userId, "bus_id": busId, "date": date]
        APIHandler().postAPIValues(type: InRejectButton.self, apiUrl: ServiceAPI.AdRejectButtonURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.fetchListAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}
}
