//
//  StudentDetailsViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 27/09/23.
//

import UIKit

class StudentDetailsViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var studentDetailsTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var details: StudentsDetails!
    var Details: InStudentDetails!
    var filtered: [StuDetails]!
    var Infiltered: [InStu]!
    
    var searching : Bool = false
    let border = Border()
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.studentDetailsTableView.delegate = self
        self.studentDetailsTableView.dataSource = self
        
        self.searchBar.delegate = self
        
        topView.layer.cornerRadius = 5
        searchBar.searchTextField.backgroundColor = .white
        
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchstudentAPI()
        fetchInstudentAPI()
    }
    
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func fetchstudentAPI() {
        APIHandler.shared.getAPIValues(type: StudentsDetails.self, apiUrl: ServiceAPI.adStudentdetailsURL,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.details = data
                DispatchQueue.main.async {
                    self.studentDetailsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    func fetchInstudentAPI() {
        APIHandler.shared.getAPIValues(type: InStudentDetails.self, apiUrl: "\(ServiceAPI.InStudentDetailsAPI)&userId=\(savedUserId)",method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.Details = data
                DispatchQueue.main.async {
                    self.studentDetailsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
                
            }
        }
    }
    
}

extension StudentDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if UserDefaultsManager.shared.getUserProfile() == "1" {
            if searching {
                return self.filtered.count
            } else {
                return self.details?.data?.count ?? 1
            }
        } else if UserDefaultsManager.shared.getUserProfile() == "2" {
            if searching {
                return self.Infiltered.count
            } else {
                return self.Details?.data?.count ?? 1
            }
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentDetailsTableViewCell", for: indexPath) as! StudentDetailsTableViewCell
        
        if UserDefaultsManager.shared.getUserProfile() == "1"{
            if let detail = searching ? self.filtered[indexPath.row] : self.details?.data?[indexPath.row] {
                cell.idLabel.text = ":     \(detail.userID ?? "")"
                cell.nameLabel.text = ":     \(detail.name ?? "")"
                cell.busIdLabel.text = ":     \(detail.busID ?? "")"
                cell.routeLabel.text = ":     \(detail.routes ?? "")"
            } else {
                cell.idLabel.text = "No data"
                cell.nameLabel.text = ""
                cell.busIdLabel.text = ""
                cell.routeLabel.text = ""
            }
        } else if UserDefaultsManager.shared.getUserProfile() == "2" {
            if let detail = searching ? self.Infiltered[indexPath.row] : self.Details?.data?[indexPath.row] {
                cell.idLabel.text = ":     \(detail.userID ?? "")"
                cell.nameLabel.text = ":     \(detail.name ?? "")"
                cell.busIdLabel.text = ":     \(detail.busID ?? "")"
                cell.routeLabel.text = ":     \(detail.routes ?? "")"
            } else {
                cell.idLabel.text = "No data"
                cell.nameLabel.text = ""
                cell.busIdLabel.text = ""
                cell.routeLabel.text = ""
            }
        }
        
        
        border.applyShadowView(to: cell.cellView)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    
}

extension StudentDetailsViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if UserDefaultsManager.shared.getUserProfile() == "1" {
            if searchText.isEmpty {
                searching = false
                filtered.removeAll()
            } else {
                searching = true
                filtered = details.data?.filter{$0.name?.range(of: searchText, options: .caseInsensitive) != nil}
            }
            studentDetailsTableView.reloadData()
        } else if UserDefaultsManager.shared.getUserProfile() == "2" {
            if searchText.isEmpty {
                searching = false
                Infiltered.removeAll()
            } else {
                searching = true
                Infiltered = Details.data?.filter{$0.name?.range(of: searchText, options: .caseInsensitive) != nil}
            }
            studentDetailsTableView.reloadData()
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
    }
}
