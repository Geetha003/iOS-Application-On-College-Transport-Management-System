//
//  SearchTableViewCell.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class SearchTableViewCell: UITableViewCell {
    
    @IBOutlet weak var occupiedlabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
   
    @IBOutlet weak var routeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var availableLabel: UILabel!
    
    @IBOutlet weak var busIdLabel: UILabel!
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var hoursLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
