//
//  PaymentStatusViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 29/09/23.
//

import UIKit

class PaymentStatusViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var paymentStatusTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.paymentStatusTableView.delegate = self
        self.paymentStatusTableView.dataSource = self
        
        topView.layer.cornerRadius = 5
    }

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

extension PaymentStatusViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PaymentStatusTableViewCell", for: indexPath) as! PaymentStatusTableViewCell
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}
