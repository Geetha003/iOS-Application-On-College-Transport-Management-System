//
//  PassengerHomeViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 28/09/23.
//

import UIKit

class PassengerHomeViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var dashboardView: UIView!
    @IBOutlet weak var busPassView: UIView!
    @IBOutlet weak var trackBusView: UIView!
    @IBOutlet weak var AttendanceView: UIView!
    @IBOutlet weak var trackBusImage: UIImageView!
    @IBOutlet weak var CalenderIMage: UIImageView!
    @IBOutlet weak var profileView: UIView!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var busPassLabel: UILabel!
    @IBOutlet weak var greenView: UIView!
    @IBOutlet weak var paymentView: UIView!
    @IBOutlet weak var menuStackView: UIStackView!
    @IBOutlet weak var requestButton: UIButton!
    @IBOutlet weak var boardingPointLabel: UILabel!
    @IBOutlet weak var validLabel: UILabel!
    @IBOutlet weak var DateLabel: UILabel!
    @IBOutlet weak var emgNoLabel: UILabel!
    @IBOutlet weak var bloodgroupLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var contact: UILabel!
    @IBOutlet weak var userId: UILabel!
    @IBOutlet weak var Address: UILabel!
    
    let border = Border()
    var pass: Profile!
    var Pass: DailyBusPass!
    var year: ValidYear!
    
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        dashboardView.isHidden = false
        profileView.isHidden = true
        menuView.isHidden = true
        greenView.isHidden = true
        paymentView.isHidden = true
        
        border.viewBorder(to: trackBusView)
        border.viewBorder(to: AttendanceView)
        border.imageBorder(to: trackBusImage)
        border.imageBorder(to: CalenderIMage)
        
        border.applyShadowView(to: busPassView)
        busPassView.clipsToBounds = true
        
        busPassLabel.layer.cornerRadius = 15
        busPassLabel.clipsToBounds = true
        
        greenView.layer.cornerRadius = 20
        
        paymentView.layer.cornerRadius = 5
        
        let tapGestureTrackBus = UITapGestureRecognizer(target: self, action: #selector(trackBusTap(_:)))
        trackBusView.addGestureRecognizer(tapGestureTrackBus)
        trackBusView.isUserInteractionEnabled = true
        
        let tapGestureAttendance = UITapGestureRecognizer(target: self, action: #selector(attendanceTap(_:)))
        AttendanceView.addGestureRecognizer(tapGestureAttendance)
        AttendanceView.isUserInteractionEnabled = true
        
        let tapGestureBusPass = UITapGestureRecognizer(target: self, action: #selector(busPassTap(_:)))
        busPassView.addGestureRecognizer(tapGestureBusPass)
        busPassView.isUserInteractionEnabled = true
    }
    
    @objc func busPassTap(_ sender: UITapGestureRecognizer) {
        greenView.isHidden = false
        busPassView.isHidden = true
    }
    
    @objc func trackBusTap(_ sender: UITapGestureRecognizer) {
        
    }
    
    @objc func attendanceTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func togglePaymentViewVisibility() {
        paymentView.isHidden = !paymentView.isHidden
        
        if paymentView.isHidden {
            // Payment view is hidden, set distribution to fill equally
            menuStackView.distribution = .fillEqually
            requestButton.isHidden = false
            menuStackView.spacing = 15
        } else {
            // Payment view is shown, set distribution to fill proportionally
            menuStackView.distribution = .fillProportionally
            requestButton.isHidden = true
            menuStackView.spacing = 5
        }
        
        
        // Set the fill proportion for the payment view (you can adjust this)
        paymentView.setContentHuggingPriority(paymentView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        paymentView.setContentCompressionResistancePriority(paymentView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        
        // Animate the layout change
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    
    @IBAction func menuButtonAction(_ sender: Any) {
        if menuView.isHidden {
            menuView.isHidden = false
            dashboardView.isHidden = true
            profileView.isHidden = true
        } else {
            menuView.isHidden = true
            if segmentController.selectedSegmentIndex == 0 {
                dashboardView.isHidden = false
                profileView.isHidden = true
            } else if segmentController.selectedSegmentIndex == 1 {
                dashboardView.isHidden = true
                profileView.isHidden = false
            }
        }
    }
    
    @IBAction func segmentAction(_ sender: Any) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            dashboardView.isHidden = false
            profileView.isHidden = true
        case 1:
            dashboardView.isHidden = true
            profileView.isHidden = false
        default:
            break
        }
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        greenView.isHidden = true
        busPassView.isHidden = false
    }
    
    @IBAction func homeButtonAction(_ sender: Any) {
        menuView.isHidden = true
        if segmentController.selectedSegmentIndex == 0 {
            dashboardView.isHidden = false
            profileView.isHidden = true
        } else if segmentController.selectedSegmentIndex == 1 {
            dashboardView.isHidden = true
            profileView.isHidden = false
        }
    }
    
    @IBAction func attendanceButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "CalenderViewController") as! CalenderViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func paymentButtonAction(_ sender: Any) {
        togglePaymentViewVisibility()
    }
    
    @IBAction func feedBackButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FeedbackViewController") as! FeedbackViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func RequestButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "RequestBusViewController") as! RequestBusViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func notificationsButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func annualPaymentAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "AnnualPaymentViewController") as! AnnualPaymentViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func changePwAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func payStatusAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "PaymentStatusViewController") as! PaymentStatusViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
        getBusPassAPI()
        getValidYearAPI()
    }
    
    @IBAction func logOutAction(_ sender: Any) {
        AlertManager.showCustomAlert(title: "Logout", message: "Do you want to logout?", viewController: self, okButtonTitle: "Logout", cancelButtonTitle: "Cancel", okHandler: {
            for controller in self.navigationController!.viewControllers as Array {
                if controller.isKind(of: InitialViewController.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
        })
    }
    func getProfileAPI() {
        APIHandler().getAPIValues(type: Profile.self, apiUrl: "\(ServiceAPI.ProfileAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                    
                    self.nameLabel.text = self.pass.data?.first?.name
                    self.Address.text = self.pass.data?.first?.address
                    self.userId.text = self.pass.data?.first?.userID
                    self.contact.text = self.pass.data?.first?.contactNumber
                    
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getBusPassAPI() {
        APIHandler().getAPIValues(type:DailyBusPass.self, apiUrl: "\(ServiceAPI.StBusPassAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.Pass = data
                print(self.Pass.data ?? "")
                DispatchQueue.main.async {
                    self.boardingPointLabel.text = self.Pass.data?.first?.routes
                    self.bloodgroupLabel.text = self.Pass.data?.first?.bloodGroup
                    self.emgNoLabel.text = self.Pass.data?.first?.contactNo
                    self.DateLabel.text = self.Pass.data?.first?.date
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getValidYearAPI() {
        APIHandler().getAPIValues(type:ValidYear.self, apiUrl: "\(ServiceAPI.ValidYearAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.year = data
                print(self.year.data ?? "")
                DispatchQueue.main.async {
                    self.validLabel.text = self.year.data?.first?.date
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
