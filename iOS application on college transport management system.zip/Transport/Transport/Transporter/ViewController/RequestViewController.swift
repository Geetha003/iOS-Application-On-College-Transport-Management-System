//
//  RequestViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class RequestViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var contentView: UIView!
    
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        
        border.applyShadowView(to: contentView)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
