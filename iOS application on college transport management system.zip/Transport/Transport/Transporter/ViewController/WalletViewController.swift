//
//  WalletViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 09/12/23.
//

import UIKit
import Razorpay

class WalletViewController: UIViewController, RazorpayProtocol {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var totalAmountLabel: UILabel!
    @IBOutlet weak var amountTextField: UITextField!
    
    var userId = UserDefaultsManager.shared.getUserID()
    var details: WalletModel!
    
    let razorpayTestKey = "rzp_test_NtuVucrYC6ACsJ"
    var razorpay: RazorpayCheckout!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        
        razorpay = RazorpayCheckout.initWithKey(razorpayTestKey, andDelegate: self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        WalletAPI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    internal func showPaymentForm(){
        let options: [String:Any] = [
            "amount": "\(self.amountTextField.text ?? "")00", //This is in currency subunits. 100 = 100 paise= INR 1.
                    "currency": "INR",//We support more that 92 international currencies.
                    "description": "", //purchase description
                    "order_id": "", //order_DBJOWzybf0sJbb
                    "image": "", //
                    "name": "Wallet",
                    "prefill": [
                        "contact": "9797979797",
                        "email": "foo@bar.com"
                    ],
                    "theme": [
                        "color": "#FFCC00"
                    ]
                ]
        razorpay.open(options, displayController: self)
    }
    
    @IBAction func addCashAction(_ sender: Any) {
        showPaymentForm()
    }
    
    func WalletAPI() {
        APIHandler.shared.getAPIValues(type: WalletModel.self,  apiUrl: "\(ServiceAPI.WalletAmountURL)user_id=\(userId ?? "")",method:"GET") { result in
            switch result {
            case .success(let data):
                self.details = data
                print(self.details.data ?? "")
                print(self.details.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.totalAmountLabel.text = "Total Amount Available: \(self.details.data?.first?.amountAvailable ?? 0)"
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
            
            }
        }
    }
    
}

extension WalletViewController : RazorpayPaymentCompletionProtocol {

    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
//        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }

    func onPaymentSuccess(_ payment_id: String) {
        print("success: ", payment_id)
//        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}

extension WalletViewController: RazorpayPaymentCompletionProtocolWithData {

    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        print("error: ", code)
//        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }

    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        print("success: ", payment_id)
//        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}


