//
//  AnnualPaymentViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 29/09/23.
//

import UIKit
import Razorpay

class AnnualPaymentViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var paymentView: UIView!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var busFeeLabel: UILabel!
    @IBOutlet weak var amountNoLabel: UILabel!
    
    @IBOutlet weak var payView: UIView!
    @IBOutlet weak var renewButton: UIButton!
    @IBOutlet weak var historyView: UIView!
    @IBOutlet weak var historyAmtLabel: UILabel!
    @IBOutlet weak var modeLabel: UILabel!
    @IBOutlet weak var refNoLabel: UILabel!
    @IBOutlet weak var historyAmtNoLabel: UILabel!
    @IBOutlet weak var onlineLabel: UILabel!
    @IBOutlet weak var refBelowLabel: UILabel!
    var pass: AnnualFee!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    
    let razorpayTestKey = "rzp_test_NtuVucrYC6ACsJ"
    var razorpay: RazorpayCheckout!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        razorpay = RazorpayCheckout.initWithKey(razorpayTestKey, andDelegate: self)
            
        topView.layer.cornerRadius = 5
        
        paymentView.layer.borderColor = UIColor.black.cgColor
        paymentView.layer.borderWidth = 0.5
        
        typeLabel.layer.borderColor = UIColor.black.cgColor
        typeLabel.layer.borderWidth = 0.5
        
        amountLabel.layer.borderColor = UIColor.black.cgColor
        amountLabel.layer.borderWidth = 0.5
        
        statusLabel.layer.borderColor = UIColor.black.cgColor
        statusLabel.layer.borderWidth = 0.5
        
        busFeeLabel.layer.borderColor = UIColor.black.cgColor
        busFeeLabel.layer.borderWidth = 0.5
        
        amountNoLabel.layer.borderColor = UIColor.black.cgColor
        amountNoLabel.layer.borderWidth = 0.5
        
        payView.layer.borderColor = UIColor.black.cgColor
        payView.layer.borderWidth = 0.5
        
        historyView.layer.borderColor = UIColor.black.cgColor
        historyView.layer.borderWidth = 0.5
        
        historyAmtLabel.layer.borderColor = UIColor.black.cgColor
        historyAmtLabel.layer.borderWidth = 0.5
        
        modeLabel.layer.borderColor = UIColor.black.cgColor
        modeLabel.layer.borderWidth = 0.5
        
        refNoLabel.layer.borderColor = UIColor.black.cgColor
        refNoLabel.layer.borderWidth = 0.5
        
        historyAmtNoLabel.layer.borderColor = UIColor.black.cgColor
        historyAmtNoLabel.layer.borderWidth = 0.5
        
        onlineLabel.layer.borderColor = UIColor.black.cgColor
        onlineLabel.layer.borderWidth = 0.5
        
        refBelowLabel.layer.borderColor = UIColor.black.cgColor
        refBelowLabel.layer.borderWidth = 0.5
        
        historyView.isHidden = true
    }
    
    internal func showPaymentForm(){
        let options: [String:Any] = [
                    "amount": "4000000", //This is in currency subunits. 100 = 100 paise= INR 1.
                    "currency": "INR",//We support more that 92 international currencies.
                    "description": "", //purchase description
                    "order_id": "", //order_DBJOWzybf0sJbb
                    "image": "", //
                    "name": "Bus Fee",
                    "prefill": [
                        "contact": "9797979797",
                        "email": "foo@bar.com"
                    ],
                    "theme": [
                        "color": "#FFCC00"
                    ]
                ]
        razorpay.open(options, displayController: self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getAnnualFeeAPI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func payAction(_ sender: Any) {
        self.showPaymentForm()
    }
    
    @IBAction func viewHistoryAction(_ sender: Any) {
        historyView.isHidden = !historyView.isHidden

            if historyView.isHidden {
                renewButton.isHidden = false
            } else {
                renewButton.isHidden = true
            }
        
        historyView.setContentHuggingPriority(historyView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)
        historyView.setContentCompressionResistancePriority(historyView.isHidden ? .defaultLow : .defaultHigh, for: .vertical)

            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            }
    }
    
    @IBAction func renewAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "RenewViewController") as! RenewViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    func getAnnualFeeAPI() {
        APIHandler().getAPIValues(type:AnnualFee.self, apiUrl: "\(ServiceAPI.AnnualFeeAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                        self.busFeeLabel.text = self.pass.data?.first?.type
                        self.amountNoLabel.text = self.pass.data?.first?.amount
                       
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                    let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle:.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in print("JSON Error")})
                    self.present(alert,animated: true, completion: nil)
                }
            }
        }
    }
}

extension AnnualPaymentViewController : RazorpayPaymentCompletionProtocol {

    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
//        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }

    func onPaymentSuccess(_ payment_id: String) {
        print("success: ", payment_id)
//        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}

extension AnnualPaymentViewController: RazorpayPaymentCompletionProtocolWithData {

    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        print("error: ", code)
//        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }

    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        print("success: ", payment_id)
//        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}
