//
//  FeedbackViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 28/09/23.
//

import UIKit

class FeedbackViewController: UIViewController {
    
    @IBOutlet weak var feedbackTextFild: UITextField!
    @IBOutlet weak var anyIssueTextField: UITextView!
    @IBOutlet weak var submitButton: UIButton!
    
    let feedBackType = ["Overall Satisfaction", "Cleanliness and Hygiene", "Accessibility", "Bus Pass and Payment", "Route and Network", "Others"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        feedbackTextFild.layer.cornerRadius = 10
        anyIssueTextField.layer.cornerRadius = 10

        submitButton.layer.cornerRadius = 10
        
        self.feedbackTextFild.delegate = self
    }
    
    @IBAction func submitButtonAction(_ sender: Any) {
        addFeedbackAPI()
    }
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    func addFeedbackAPI() {
        guard let user_id = UserDefaultsManager.shared.getUserID() else {
            return
        }
        let formData: [String: String] = [
            "user_id": user_id,
            "feedback_type": feedbackTextFild.text ?? "",
            "description": anyIssueTextField.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: AddFeedback.self, apiUrl: ServiceAPI.addFeedbackURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                   print(formData)
                    AlertManager.showAutoPopAlert(title: "Success", message: "Feedback submitted Successfully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}

extension FeedbackViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let alert = UIAlertController(title: "Select Feedback Type", message: "", preferredStyle: .actionSheet)
        
        for type in feedBackType {
            alert.addAction(UIAlertAction(title: type, style: .default, handler: { action in
                self.feedbackTextFild.text = type
            }))
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        self.present(alert, animated: true)
    }
}
