//
//  RequestBusViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 29/09/23.
//

import UIKit

class RequestBusViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var busDetailsTableView: UITableView!
    
  
    @IBOutlet weak var searchbar: UISearchBar!
    
    var details: RequestBus!
    var filtered: [Rebus]!
    let border = Border()
    var busId = String()
    var searching : Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.busDetailsTableView.delegate = self
        self.busDetailsTableView.dataSource = self
        self.busDetailsTableView.isHidden = true
        self.searchbar.delegate = self
        
        topView.layer.cornerRadius = 5
    }
    override func viewWillAppear(_ animated: Bool) {
        fetchRequestBusAPI()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func availableButtonAction(_ sender: Any) {
        self.busDetailsTableView.isHidden = false
        fetchRequestBusAPI()
    }
    
    func fetchRequestBusAPI() {
        APIHandler.shared.getAPIValues(type: RequestBus.self, apiUrl: ServiceAPI.stRequestBusURL ,method:"GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.details = data
                DispatchQueue.main.async {
                    self.busDetailsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            
            }
        }
    }
    
}

extension RequestBusViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return self.filtered.count
        } else {
            return self.details?.data?.count ?? 1
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BusDetailsTableViewCell", for: indexPath) as! BusDetailsTableViewCell
        if let detail = searching ? self.filtered[indexPath.row] : self.details?.data?[indexPath.row]{
//            busId = detail.busID ?? ""
            cell.idLabel.text = "Bus Id: \(detail.busID ?? "")"
            
            cell.routeLabel.text = " Bus Route: \(detail.routes ?? "")"
           
        } else {
            cell.idLabel.text = "No data"
            cell.routeLabel.text = ""
           
        }
        
        cell.availableButton.setTitle("Request", for: .normal)
        cell.availableButton.layer.cornerRadius = 5
        cell.availableButton.addAction(for: .tap) {
            guard let userId = UserDefaultsManager.shared.getUserID() else {
                return
            }
            let busId = self.filtered?[indexPath.row].busID

            self.busDetailsTableView.reloadData()
                let formData: [String: String] = ["userId": userId, "busId": busId ?? ""]
            APIHandler().postAPIValues(type: StuRequest.self, apiUrl: ServiceAPI.studentRequestURL , method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        self.fetchRequestBusAPI()
                        AlertManager.showAutoDismissAlert(title: "\(response.status)", message: " \(response.message)", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    // Handle error
                }
            }
        }
        
        border.applyShadowView(to: cell.cellView)
        cell.cellView.layer.borderWidth = 0.5
        cell.cellView.layer.borderColor = UIColor.black.cgColor
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
extension RequestBusViewController: UISearchBarDelegate {
    
    func searchBar(_ searchbar: UISearchBar, textDidChange searchText: String) {

            if searchText.isEmpty {
                searching = false
                filtered.removeAll()
            } else {
                searching = true
                filtered = details.data?.filter{$0.routes?.range(of: searchText, options: .caseInsensitive) != nil}
            }
        busDetailsTableView.reloadData()

    }

    func searchBarCancelButtonClicked(_ searchbar: UISearchBar) {
        searchbar.text = ""
    }
}
