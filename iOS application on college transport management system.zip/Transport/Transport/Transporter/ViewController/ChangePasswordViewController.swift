//
//  ChangePasswordViewController.swift
//  Transport
//
//  Created by SAIL01 on 18/11/23.
//

import UIKit

class ChangePasswordViewController: UIViewController {

    @IBOutlet weak var oldLabel: UITextField!
    @IBOutlet weak var newLabel: UITextField!
    @IBOutlet weak var confirmLabel: UITextField!
    @IBOutlet weak var submitLabel: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func BackButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func SubmitButton(_ sender: Any) {
        if oldLabel.text?.isEmpty == true || newLabel.text?.isEmpty == true || confirmLabel.text?.isEmpty == true {
            AlertManager.showAlert(title: "Alert", message: "Please Enter the Values", viewController: self)
        } else {
            changepasswordAPI()
        }
    }
    
    func changepasswordAPI() {
        guard let user_id = UserDefaultsManager.shared.getUserID() else {
            return
        }
        let formData: [String: String] = [
            "user_id": user_id,
            "old_password": oldLabel.text ?? "",
            "new_password": newLabel.text ?? "",
            "confirm_password": confirmLabel.text ?? ""
            
        ]
        APIHandler().postAPIValues(type: changepass.self, apiUrl: ServiceAPI.changepasswordURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status ?? "")")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                   print(formData)
                    AlertManager.showAutoPopAlert(title: "\(response.status ?? "")", message: "\(response.message ?? "")", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }

}
