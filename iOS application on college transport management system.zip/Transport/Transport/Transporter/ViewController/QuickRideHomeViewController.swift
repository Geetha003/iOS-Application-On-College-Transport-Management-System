//
//  QuickRideHomeViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class QuickRideHomeViewController: UIViewController {
    
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var dashboardView: UIView!
    @IBOutlet weak var boardBusView: UIView!
    @IBOutlet weak var boardBusImage: UIImageView!
    @IBOutlet weak var trackBusView: UIView!
    @IBOutlet weak var trackBusImage: UIImageView!
    @IBOutlet weak var busPassView: UIView!
    @IBOutlet weak var busPassImage: UIImageView!
    @IBOutlet weak var profileView: UIView!
    @IBOutlet weak var segmentController: UISegmentedControl!
    @IBOutlet weak var profileNameLabel: UILabel!
    @IBOutlet weak var contactLabel: UILabel!
    @IBOutlet weak var busIdLabel: UILabel!
    @IBOutlet weak var AddressLabel: UILabel!
    
    let border = Border()
    var pass: Profile!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        dashboardView.isHidden = false
        profileView.isHidden = true
        menuView.isHidden = true
        
        border.viewBorder(to: trackBusView)
        border.viewBorder(to: boardBusView)
        border.viewBorder(to: busPassView)
        
        border.imageBorder(to: trackBusImage)
        border.imageBorder(to: boardBusImage)
        border.imageBorder(to: busPassImage)
        
        let tapGestureBoardBus = UITapGestureRecognizer(target: self, action: #selector(boardBusTap(_:)))
        boardBusView.addGestureRecognizer(tapGestureBoardBus)
        boardBusView.isUserInteractionEnabled = true
        
        //Wallet
        let tapGestureTrackBus = UITapGestureRecognizer(target: self, action: #selector(walletTap(_:)))
        trackBusView.addGestureRecognizer(tapGestureTrackBus)
        trackBusView.isUserInteractionEnabled = true
        
        let tapGestureBusPass = UITapGestureRecognizer(target: self, action: #selector(busPassTap(_:)))
        busPassView.addGestureRecognizer(tapGestureBusPass)
        busPassView.isUserInteractionEnabled = true
    }
    
    @objc func boardBusTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "CheckTransportViewController") as! CheckTransportViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func walletTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "WalletViewController") as! WalletViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func busPassTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "BusPassViewController") as! BusPassViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func menuButtonAction(_ sender: Any) {
        if menuView.isHidden {
               menuView.isHidden = false
               dashboardView.isHidden = true
               profileView.isHidden = true
           } else {
               menuView.isHidden = true
               if segmentController.selectedSegmentIndex == 0 {
                   dashboardView.isHidden = false
                   profileView.isHidden = true
               } else if segmentController.selectedSegmentIndex == 1 {
                   dashboardView.isHidden = true
                   profileView.isHidden = false
               }
           }
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        switch segmentController.selectedSegmentIndex {
        case 0:
            dashboardView.isHidden = false
            profileView.isHidden = true
        case 1:
            dashboardView.isHidden = true
            profileView.isHidden = false
        default:
            break
        }
    }
    
    @IBAction func homeButtonAction(_ sender: Any) {
        menuView.isHidden = true
        if segmentController.selectedSegmentIndex == 0 {
            dashboardView.isHidden = false
            profileView.isHidden = true
        } else if segmentController.selectedSegmentIndex == 1 {
            dashboardView.isHidden = true
            profileView.isHidden = false
        }
    }
    
    
    @IBAction func notificationButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func feedbackButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FeedbackViewController") as! FeedbackViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func changePwAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
    }
    
    @IBAction func logOutButtonAction(_ sender: Any) {
        AlertManager.showCustomAlert(title: "Logout", message: "Do you want to logout?", viewController: self, okButtonTitle: "Logout", cancelButtonTitle: "Cancel", okHandler: {
            for controller in self.navigationController!.viewControllers as Array {
                if controller.isKind(of: InitialViewController.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
        })
    }
    
    func getProfileAPI() {
        APIHandler().getAPIValues(type: Profile.self, apiUrl: "\(ServiceAPI.ProfileAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                DispatchQueue.main.async {
                    self.profileNameLabel.text = self.pass.data?.first?.name
                    self.AddressLabel.text = self.pass.data?.first?.address
                    self.busIdLabel.text = self.pass.data?.first?.userID
                    self.contactLabel.text = self.pass.data?.first?.contactNumber
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                }
            }
        }
    }
    
}
