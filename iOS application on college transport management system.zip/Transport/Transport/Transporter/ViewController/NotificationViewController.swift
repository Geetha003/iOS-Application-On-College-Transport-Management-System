//
//  NotificationViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 29/09/23.
//

import UIKit
import Razorpay

class NotificationViewController: UIViewController {
    
    @IBOutlet weak var notificationsTableView: UITableView!
    
    let razorpayTestKey = "rzp_test_NtuVucrYC6ACsJ"
    var razorpay: RazorpayCheckout!

    var details: StudentNotification!
    var Details: StDayNotification!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.notificationsTableView.delegate = self
        self.notificationsTableView.dataSource = self
        
        razorpay = RazorpayCheckout.initWithKey(razorpayTestKey, andDelegate: self)
    }
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    internal func showPaymentForm(){
        let options: [String:Any] = [
                    "amount": "3000", //This is in currency subunits. 100 = 100 paise= INR 1.
                    "currency": "INR",//We support more that 92 international currencies.
                    "description": "", //purchase description
                    "order_id": "", //order_DBJOWzybf0sJbb
                    "image": "", //
                    "name": "Bus Fee",
                    "prefill": [
                        "contact": "9797979797",
                        "email": "foo@bar.com"
                    ],
                    "theme": [
                        "color": "#FFCC00"
                    ]
                ]
        razorpay.open(options, displayController: self)
    }
   
    override func viewWillAppear(_ animated: Bool) {
        fetchStNotificationAPI()
        fetchStDayNotificationAPI() 
    }
   
    func fetchStNotificationAPI() {
        APIHandler.shared.getAPIValues(type: StudentNotification.self,  apiUrl: "\(ServiceAPI.StudentNotificationAPI)&userId=\(savedUserId)" ,method:"GET") { result in
            switch result {
            case .success(let data):
                self.details = data
                print(self.details.data ?? "")
                print(self.details.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.notificationsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                    let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle:.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in print("JSON Error")})
                    self.present(alert,animated: true, completion: nil)
                }
            
            }
        }
    }
    func fetchStDayNotificationAPI() {
        APIHandler.shared.getAPIValues(type: StDayNotification.self,  apiUrl: "\(ServiceAPI.DayStudentNotificationAPI)&userId=\(savedUserId)",method:"GET") { result in
            switch result {
            case .success(let data):
                self.Details = data
                print(self.Details.data ?? "")
                print(self.Details.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.notificationsTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                    let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle:.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in print("JSON Error")})
                    self.present(alert,animated: true, completion: nil)
                }
            
            }
        }
    }
    
    @objc func payAction() {
        self.showPaymentForm()
    }
    
}

extension NotificationViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if UserDefaultsManager.shared.getUserProfile() == "4" {
            return self.details?.data?.count ?? 1
        } else if UserDefaultsManager.shared.getUserProfile() == "3" {
            return self.Details?.data?.count ?? 1
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NotificationsTableViewCell", for: indexPath) as! NotificationsTableViewCell
        
        if UserDefaultsManager.shared.getUserProfile() == "4"{
            cell.payButton.isHidden = true
            if let detail = self.details?.data?[indexPath.row] {
                cell.busIdLabel.text = "Bus Id: \(detail.busID ?? "")"
                cell.statusLabel.text = " \(detail.status ?? "")"
                cell.dteLabel.text = " \(detail.date ?? "")"
                cell.userIdLabel.text = " \(detail.studentID ?? "")"
            } else {
                cell.busIdLabel.text = "No data"
                cell.statusLabel.text = ""
                cell.dteLabel.text = ""
                cell.userIdLabel.text = ""
            }
        } else if UserDefaultsManager.shared.getUserProfile() == "3" {
            cell.payButton.addTarget(self, action: #selector(payAction), for: .touchUpInside)
            if let detail = self.Details?.data?[indexPath.row] {
                cell.busIdLabel.text = "Bus Id: \(detail.busID ?? "")"
                cell.statusLabel.text = " \(detail.status ?? "")"
                cell.dteLabel.text = " \(detail.date ?? "")"
                cell.userIdLabel.text = " \(detail.studentID ?? "")"
                
                if detail.status == "Accepted" {
                    cell.payButton.isHidden = false
                } else {
                    cell.payButton.isHidden = true
                }
                
            } else {
                cell.busIdLabel.text = "No data"
                cell.statusLabel.text = ""
                cell.dteLabel.text = ""
                cell.userIdLabel.text = ""
            }
        }
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
}

extension NotificationViewController : RazorpayPaymentCompletionProtocol {

    func onPaymentError(_ code: Int32, description str: String) {
        print("error: ", code, str)
//        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }

    func onPaymentSuccess(_ payment_id: String) {
        print("success: ", payment_id)
//        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}

extension NotificationViewController: RazorpayPaymentCompletionProtocolWithData {

    func onPaymentError(_ code: Int32, description str: String, andData response: [AnyHashable : Any]?) {
        print("error: ", code)
//        self.presentAlert(withTitle: "Alert", message: str)
        AlertManager.showAlert(title: "Alert", message: str, viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Alert", message: str, viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }

    func onPaymentSuccess(_ payment_id: String, andData response: [AnyHashable : Any]?) {
        print("success: ", payment_id)
//        self.presentAlert(withTitle: "Success", message: "Payment Succeeded")
        AlertManager.showAlert(title: "Success", message: "Payment Succeeded", viewController: self)
//        AlertManager.showAutoDismissAlert(title: "Success", message: "Payment Succeeded", viewController: self, navigationController: self.navigationController!, duration: 2.0)
    }
}

