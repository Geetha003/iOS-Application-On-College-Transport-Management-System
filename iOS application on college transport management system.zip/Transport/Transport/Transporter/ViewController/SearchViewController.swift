//
//  SearchViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class SearchViewController: UIViewController {
    
    @IBOutlet weak var RouteLabel: UILabel!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var searchTableView: UITableView!
    
    var details: DayCheckAvailable!
    var filtered: [daycheckavl]!
    var boardingPoint = UserDefaultsManager.shared.getBoardingPoint() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.searchTableView.delegate = self
        self.searchTableView.dataSource = self
        
        topView.layer.cornerRadius = 20
    }
    
    override func viewWillAppear(_ animated: Bool) {
        checkAvailableAPI()
    }
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func checkAvailableAPI() {
        APIHandler.shared.getAPIValues(type: DayCheckAvailable.self,  apiUrl:"\(ServiceAPI.DayCheckAvailableAPI)&routes=\(boardingPoint)",method:"GET") { result in
            switch result {
            case .success(let data):
                self.details = data
                print(self.details.data ?? "")
                print(self.details.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.RouteLabel.text = " \((self.details.data?.first?.routes ?? ""))"
                    self.searchTableView.reloadData()
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                }
            
            }
        }
    }
    
}

extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.details?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchTableViewCell", for: indexPath) as! SearchTableViewCell
        
//        cell.accpetButton.tag = indexPath.row
//        cell.accpetButton.addTarget(self, action: #selector(acceptButton(sender:)), for: .touchUpInside)
        
        cell.busIdLabel.tag = indexPath.row
        
        if let detail = self.details?.data?[indexPath.row] {
            cell.busIdLabel.text = "Bus Id:  \(detail.busID ?? "")"
            cell.routeLabel.text = "Route:  \(detail.routes ?? "")"
            cell.totalLabel.text = "Total:  \(detail.totalSeats ?? 0)"
            cell.occupiedlabel.text = "Occupied:  \(detail.occupiedSeats ?? 0)"
            cell.availableLabel.text = "Available:  \(detail.availableSeats ?? 0)"
            cell.nameLabel.text = "  \(detail.driverName ?? "")"
           
        } else {
            cell.busIdLabel.text = "No data"
            cell.routeLabel.text = ""
            cell.totalLabel.text = ""
            cell.occupiedlabel.text = ""
            cell.availableLabel.text = ""
            cell.nameLabel.text = ""
           
        }
        
        cell.cellView.layer.cornerRadius = 30
        cell.hoursLabel.layer.cornerRadius = cell.hoursLabel.frame.height / 2
        cell.cellView.clipsToBounds = true
        
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "Request for the Bus?", message: "", preferredStyle: UIAlertController.Style.alert)      //Create_Alert
        alert.addAction(UIAlertAction(title: "Request", style: UIAlertAction.Style.default, handler: { action in
            self.requestAction(indexPath: indexPath)
        }))       //Add_Actions(Buttons)
                alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.cancel))
                self.present(alert, animated: true)
    }
    
    func requestAction(indexPath: IndexPath) {
//        let vc = storyboard?.instantiateViewController(withIdentifier: "RequestViewController") as! RequestViewController
//        navigationController?.pushViewController(vc, animated: true)
        
        guard let userId = UserDefaultsManager.shared.getUserID() else {
            return
        }
        
      //  let busId = self.filtered?[indexPath.row].busID
        guard let busId = self.details.data?[indexPath.row].busID else {
            return
        }
        self.searchTableView.reloadData()
            let formData: [String: String] = ["userId": userId, "busId": busId ?? ""]
        APIHandler().postAPIValues(type: DayStuRequest.self, apiUrl: ServiceAPI.studentDayRequestURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.navigationController?.popViewController(animated: true)
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
}
