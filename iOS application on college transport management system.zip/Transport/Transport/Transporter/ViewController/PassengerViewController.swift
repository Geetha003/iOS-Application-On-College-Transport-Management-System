//
//  PassengerViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 28/09/23.
//

import UIKit

class PassengerViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var passengerView: UIView!
    @IBOutlet weak var rideView: UIView!
    @IBOutlet weak var dailyPassengerView: UIView!
    @IBOutlet weak var dailyPassengerImage: UIImageView!
    @IBOutlet weak var quickRideView: UIView!
    @IBOutlet weak var quickRideimage: UIImageView!
    
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 30
        topView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        border.applyShadowView(to: dailyPassengerView)
        border.imageBorder(to: dailyPassengerImage)
        
        border.applyShadowView(to: quickRideView)
        border.imageBorder(to: quickRideimage)
                
        let tapGesturePassenger = UITapGestureRecognizer(target: self, action: #selector(PassengerTap(_:)))
        passengerView.addGestureRecognizer(tapGesturePassenger)
        passengerView.isUserInteractionEnabled = true
        
        let tapGestureRide = UITapGestureRecognizer(target: self, action: #selector(RideTap(_:)))
        rideView.addGestureRecognizer(tapGestureRide)
        rideView.isUserInteractionEnabled = true
    }
    
    @objc func PassengerTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func RideTap(_ sender: UITapGestureRecognizer) {
        let storyboard = UIStoryboard(name: "TransporterStoryboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}
