//
//  RenewViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 29/09/23.
//

import UIKit

class RenewViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var renewView: UIView!
    
    let border = Border()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        
        border.applyShadowView(to: renewView)
    }

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func renewButtonAction(_ sender: Any) {
        let alert = UIAlertController(title: "Do you want to renew payment?", message: "", preferredStyle: UIAlertController.Style.alert)      //Create_Alert
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
            self.renewAction()
        }))       //Add_Actions(Buttons)
                alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.cancel))
                self.present(alert, animated: true)
    }
    
    func renewAction() {
        navigationController?.popViewController(animated: true)
    }
    
}
