
//
//  BusPassViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class BusPassViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var busPassView: UIView!
    @IBOutlet weak var busPassLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var numLabel: UILabel!
    @IBOutlet weak var boardingLabel: UILabel!
    @IBOutlet weak var bloodGrp: UILabel!
    
    let border = Border()
    
    var pass: BusPassModel!
    var login : LoginModel!
    var savedUserId = UserDefaultsManager.shared.getUserID() ?? ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        
        border.applyShadowView(to: busPassView)
        busPassView.clipsToBounds = true
        
        busPassLabel.layer.cornerRadius = 15
        busPassLabel.clipsToBounds = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getBusPassAPI()
    }

    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func getBusPassAPI() {
        APIHandler().getAPIValues(type: BusPassModel.self, apiUrl: "\(ServiceAPI.BusPassAPI)&userId=\(savedUserId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.pass = data
                print(self.pass.data ?? "")
                
                DispatchQueue.main.async {
                        self.boardingLabel.text = self.pass.data?.first?.routes
                        self.bloodGrp.text = self.pass.data?.first?.bloodGroup
                        self.numLabel.text = self.pass.data?.first?.contactNo
                        self.dateLabel.text = self.pass.data?.first?.date
                    
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async{
                    
                    let alert = UIAlertController(title: "Warning", message: "Incorrect Password or ID", preferredStyle:.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .destructive) { ok in print("JSON Error")})
                    self.present(alert,animated: true, completion: nil)
                }
            }
        }
    }
    
}
