//
//  CheckTransportViewController.swift
//  Transport
//
//  Created by Haris Madhavan on 30/09/23.
//

import UIKit

class CheckTransportViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var checkView: UIView!
    
    @IBOutlet weak var droppingpoint: UITextField!
    @IBOutlet weak var boargingpoint: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        topView.layer.cornerRadius = 5
        border.applyShadowView(to: checkView)
        
        droppingpoint.text = "Saveetha University"
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func searchAction(_ sender: Any) {
        if boargingpoint.text == "" {
            AlertManager.showAlert(title: "Enter the Value", message: "Please enter the boarding point.", viewController: self)
        } else {
            let vc = storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
            navigationController?.pushViewController(vc, animated: true)
            UserDefaultsManager.shared.saveBoardingPoint(self.boargingpoint.text ?? "")
        }
    }

}
