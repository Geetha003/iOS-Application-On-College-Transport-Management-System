//
//  NotificationsTableViewCell.swift
//  Transport
//
//  Created by Haris Madhavan on 29/09/23.
//

import UIKit

class NotificationsTableViewCell: UITableViewCell {

    @IBOutlet weak var busIdLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var dteLabel: UILabel!
    @IBOutlet weak var userIdLabel: UILabel!
    @IBOutlet weak var payButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
