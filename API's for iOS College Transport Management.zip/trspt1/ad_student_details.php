<?php
// Include the database conn file
require_once('db_conn.php');

// Define the SQL query
$sql = "
SELECT DISTINCT  ts.Name, ts.user_Id,  IFNULL(br.busId, '') AS busId, IFNULL(bd.routes, '') AS routes
FROM transporter_signup ts
LEFT JOIN bus_requests br ON ts.user_Id = br.student_id
LEFT JOIN bus_details bd ON br.busId = bd.bus_id
WHERE ts.user_Id LIKE 'st%' OR ts.user_Id LIKE 'sd%'
";

// Execute the query
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $output = ["data" => $data]; // Wrap the data array under the "data" key
    // Return the data as JSON
    echo json_encode($output);
} else {
    echo "No matching data found.";
}

// Close the database conn (optional, as PHP will automatically close it when the script finishes)
$conn->close();
?>
