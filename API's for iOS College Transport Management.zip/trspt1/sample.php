

<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the busId and user_id from the POST data
    $busId = $_POST['busId'];
    $user_id = $_POST['userId']; // Replace 'your_user_id' with the actual method to obtain the user_id

    // Set the status to "pending"

    // Insert a new row into the bus_requests table
    $sql = "INSERT INTO bus_requests (busId, student_id) VALUES ('$busId', '$user_id')";
    $result = $conn->query($sql);

    if ($result === TRUE) {
        // If the insertion is successful, return a success response
        $response = array('status' => 'Success', 'message' => 'Request sent successfully.');
        echo json_encode($response);
    } else {
        // If there is an error in the insertion, return an error response
        $response = array('status' => 'Error', 'message' => 'Failed to send request.');
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'Error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
