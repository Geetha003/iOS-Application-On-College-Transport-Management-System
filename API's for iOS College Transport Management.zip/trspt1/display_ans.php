<?php
require_once('dbconfig.php'); // Include your database configuration

$userid = $_GET['userid']; // Replace with your user identifier

$query = "SELECT a.*, q.question
          FROM answers a
          JOIN questions q ON q.questionid BETWEEN 1 AND 30
          WHERE a.userid = ?
          ORDER BY q.questionid";

// Prepare and execute the query, passing the user ID as a parameter
$stmt = $dbconn->prepare($query);
$stmt->bind_param('i', $userid); // Assumes userid is an integer, adjust as needed
$stmt->execute();
$result = $stmt->get_result();

$response = array();

while ($row = $result->fetch_assoc()) {
    $response[] = array(
        'question_id' => $row['questionid'],
        'question_text' => $row['question'],
        'user_answer' => $row['user_answer'],
        'submitted_date' => $row['submitted_date'],
    );
}

header('Content-Type: application/json');
echo json_encode(['data' => $response]);
?>
