<?php
// Include the database connection file
require_once('db_conn.php');

// Check if the 'userId' parameter is provided in the URL (from login credentials)
if (isset($_GET['userId'])) {
    $userId = $_GET['userId'];

    // Query to check if the 'userId' is present in the 'bus_details' table under 'busInchargeId' column
    $checkBusInchargeQuery = "SELECT bus_id,routes FROM bus_details WHERE busInchargeID = ?";

    // Prepare and execute the query
    $stmt = $conn->prepare($checkBusInchargeQuery);
    $stmt->bind_param("s", $userId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // 'userId' is found in 'bus_details' table, fetch 'bus_id' and additional fields
            $row = $result->fetch_assoc();
            $busId = $row['bus_id'];
            $busField1 = $row['routes'];

            // Query to fetch 'bus_requests' where 'student_id' starts with 'f', 'status' is 'accepted,' and 'bus_id' matches
            $fetchBusRequestsQuery = "SELECT student_id FROM bus_requests WHERE busId = ? AND (student_id LIKE 'f%') AND status = 'accepted'";

            // Prepare and execute the query
            $stmt = $conn->prepare($fetchBusRequestsQuery);
            $stmt->bind_param("s", $busId);

            if ($stmt->execute()) {
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $data = array();
                    while ($row = $result->fetch_assoc()) {
                        $studentId = $row['student_id'];
                        // Query to fetch details from 'transporter_signup' table using 'student_id'
                        $fetchTransporterDetailsQuery = "SELECT user_Id, Name, contact_no FROM transporter_signup WHERE user_Id = ?";
                        
                        // Prepare and execute the query
                        $stmt = $conn->prepare($fetchTransporterDetailsQuery);
                        $stmt->bind_param("s", $studentId);

                        if ($stmt->execute()) {
                            $transporterDetails = $stmt->get_result()->fetch_assoc();
                            $data[] = array(
                                'user_id' => $transporterDetails['user_Id'],
                                'name' => $transporterDetails['Name'],
                                'bus_id' => $busId,
                                'contact_no' => $transporterDetails['contact_no'],
                                
                            );
                        }
                    }
                  
                    // Return the data as JSON
                    $output = ["data" => $data]; // Wrap the data array under the "data" key
                    // Return the data as JSON
                    echo json_encode($output);
                } else {
                    echo "No matching bus requests found for bus ID: $busId with status 'accepted'.";
                }
            } else {
                echo "Query error: " . $stmt->error;
            }
        } else {
            echo "User ID '$userId' is not found in bus_details table under busInchargeId column.";
        }
    } else {
        echo "Query error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Please provide a 'userId' parameter in the URL.";
}

// Close the database connection
$conn->close();
?>
