<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $busid = $_POST['busid'];
    $bus_route = $_POST['bus_route'];
    $total_seats = $_POST['total_seats'];
    $available_seats = $_POST['available_seats'];
    $occupied_seats = $_POST['occupied_seats'];
    $driver_name = $_POST['driver_name'];
    $driver_contact_no = $_POST['driver_contact_no'];
    $incharge_id = $_POST['incharge_id'];
    $incharge_name = $_POST['incharge_name'];
    $incharge_mobile_no = $_POST['incharge_mobile_no'];

    // Insert data into the bus_details table
    $sql = "INSERT INTO bus_details (bus_id, routes, total_seats, available_seats, occupied_seats, driver_name, driver_contact, busInChargeID) VALUES ('$busid', '$bus_route', '$total_seats', '$available_seats', '$occupied_seats', '$driver_name', '$driver_contact_no', '$incharge_id')";

    if ($conn->query($sql) === TRUE) {
        // Successful insertion
        $response = array('status' => 'success', 'message' => 'Bus details added successfully.');
        echo json_encode($response);
    } else {
        // Error in database insertion
        $response = array('status' => 'Error', 'message' => 'Error: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'Error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
