<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Get the routes input from the request
$routes = $_GET['routes'];

// Specify the columns you want to retrieve
$selectedColumns = 'bus_id, routes, total_seats, available_seats, occupied_seats, driver_name'; // Replace with the actual column names you need

// Prepare a SQL query to retrieve details from bus-details based on the routes
$sql = "SELECT $selectedColumns FROM bus_details WHERE routes = ?";

// Use prepared statements to prevent SQL injection
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $routes);
$stmt->execute();

// Get the results
$result = $stmt->get_result();

// Initialize an array to store the retrieved data
$bus_details = array();

// Fetch data from the result set
while ($row = $result->fetch_assoc()) {
    $bus_details[] = $row;
}

// Create a "data" array and place the results inside it
$data = array('data' => $bus_details);

// Return the data as JSON
echo json_encode($data);

// Close the database connection
$stmt->close();
$conn->close();
?>
