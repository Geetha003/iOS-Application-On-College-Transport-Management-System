<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the busId and user_id from the POST data
    $busId = $_POST['busId'];
    $user_id = $_POST['userId']; // Replace 'your_user_id' with the actual method to obtain the user_id

    // Check if a request with the same user_id, accepted status, and today's date exists
    $checkSql = "SELECT * FROM day_request WHERE student_id = '$user_id' AND status = 'Accepted' AND DATE(date) = CURDATE()";
    $checkResult = $conn->query($checkSql);

    if ($checkResult->num_rows > 0) {
        // Request already present for the user with accepted status and today's date
        $response = array('status' => 'Error', 'message' => 'Request already present for the user with Accepted status.');
        echo json_encode($response);
    } else {
        // Insert a new row into the bus_requests table with status set to "pending"
        $insertSql = "INSERT INTO day_request (busId, student_id) VALUES ('$busId', '$user_id')";
        $insertResult = $conn->query($insertSql);

        if ($insertResult === TRUE) {
            // If the insertion is successful, return a success response
            $response = array('status' => 'Success', 'message' => 'Request sent successfully.');
            echo json_encode($response);
        } else {
            // If there is an error in the insertion, return an error response
            $response = array('status' => 'Error', 'message' => 'Failed to send request.');
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'Error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
