<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Get the user_id from the login credentials (replace this with your method of getting the user_id)
$user_id = $_GET['userId']; // Replace with your user_id retrieval code

// Get the current date
$current_date = date("Y-m-d");

// Initialize an array to store the results
$results = array();

// Check if there are matching rows in the bus_requests table

// Check if there are matching rows in the day_request table with today's date
$sqlDay = "SELECT busId, status, date FROM day_request WHERE student_id = '$user_id' AND date = '$current_date'";
$resultDay = $conn->query($sqlDay);

if ($resultDay->num_rows > 0) {
    while ($row = $resultDay->fetch_assoc()) {
        // Retrieve busId, status, and date from each matching row in day_request
        $busId = $row['busId'];
        $status = $row['status'];
        $date = $row['date'];

        // Create a result entry for each matching row in day_request
        $result_entry = array(
            
            'busId' => $busId,
            'status' => $status,
            'date' => $date,
        );

        // Add the result entry to the results array
        $results[] = $result_entry;
    }
}

// Return the combined results as JSON
$response = array('data' => $results);
echo json_encode($response);

// Close the database connection
$conn->close();
?>
