<?php
// Include the database connection file
require_once('db_conn.php');

// Define the SQL query to fetch pending requests from the bus_requests table
$sql = "SELECT student_id, busId, status, date FROM bus_requests WHERE status = 'pending'";

// Execute the query
$result = $conn->query($sql);

if ($result === false) {
    die("Query error: " . $conn->error);
}

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    // Return the data as JSON
    $output = ["data" => $data]; // Wrap the data array under the "data" key
    // Return the data as JSON
    echo json_encode($output);
} else {
    echo "No pending requests found.";
}

// Close the database connection
$conn->close();
?>
