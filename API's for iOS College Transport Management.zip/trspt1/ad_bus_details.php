<?php
// Include the database conn$conn file
require_once('db_conn.php');

// Define the SQL query to fetch all data from the bus_details table
$sql = "SELECT bus_id, routes FROM bus_details";

// Execute the query
$result = $conn->query($sql);

if ($result === false) {
    die("Query error: " . $conn->error);
}

if ($result->num_rows > 0) {
    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $output = ["data" => $data]; // Wrap the data array under the "data" key
    // Return the data as JSON
    echo json_encode($output);// Return the data as JSON
} else {
    echo "No data found in bus_details table.";
}

// Close the database conn$conn
$conn->close();
?>
