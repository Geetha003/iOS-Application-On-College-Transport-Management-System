<?php
// Include the database connection file
require_once('db_conn.php');

// Check if the 'bus_id' parameter is provided in the URL
if (isset($_GET['bus_id'])) {
    $bus_id = $_GET['bus_id'];

    // Define the SQL query to fetch data for the specified 'bus_id'
    $sql = "SELECT total_seats, available_seats, occupied_seats, driver_name, driver_contact FROM bus_details WHERE bus_id = ?";

    // Prepare and execute a parameterized query
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $bus_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $data = $result->fetch_assoc();
            // Wrap the data in a "data" array
            $response = array('data' => array($data));
            // Return the data as JSON
            echo json_encode($response);
        } else {
            echo "No data found for bus ID: $bus_id";
        }
    } else {
        echo "Query error: " . $stmt->error;
    }  

    // Close the statement
    $stmt->close();
} else {
    echo "Please provide a 'bus_id' parameter in the URL.";
}

// Close the database connection
$conn->close();
?>
