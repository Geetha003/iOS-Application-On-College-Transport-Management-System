<?php
error_reporting(0);
require_once('db_conn.php');

// Database query to retrieve all data from the transporter_signup table
$loginqry = "SELECT * FROM transporter_signup";
$qry = mysqli_query($conn, $loginqry);

// Prepare the response
$response = [];

if (mysqli_num_rows($qry) > 0) {
    $userArray = [];
    while ($userObj = mysqli_fetch_assoc($qry)) {
        $userArray[] = $userObj;
    }
    $response['status'] = true;
    $response['message'] = "Data Retrieved Successfully";
    $response['data'] = $userArray;
} else {
    $response['status'] = false;
    $response['message'] = "No Data Found";
}

// Set the HTTP response headers
header('Content-Type: application/json; charset=UTF-8');

// Send the JSON response
echo json_encode($response);
?>
