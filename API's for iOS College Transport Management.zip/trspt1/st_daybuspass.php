<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Get the user_id from the request
$user_id = $_GET['userId'];

// Initialize an array to store the final data
$final_data = array();

// Get the current date in the format 'Y-m-d'
$current_date = date('Y-m-d');

// Retrieve blood_group and contact_no from transporter_signup
$sql1 = "SELECT blood_group, contact_no FROM transporter_signup WHERE user_Id = '$user_id'";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    $row1 = $result1->fetch_assoc();
    $blood_group = $row1['blood_group'];
    $contact_no = $row1['contact_no'];

    // Retrieve bus requests for the same user_id with status 'Accepted' and date equal to today
    $sql2 = "SELECT busId, date FROM day_request WHERE student_id = '$user_id' AND status = 'Accepted' AND date = '$current_date'";
    $result2 = $conn->query($sql2);

    if ($result2->num_rows > 0) {
        while ($row2 = $result2->fetch_assoc()) {
            $bus_id = $row2['busId'];
            $date = date("Y-m-d", strtotime($row2['date'] . " +1 year")); // Add 1 year to the date

            // Retrieve bus route from bus_details
            $sql3 = "SELECT routes FROM bus_details WHERE bus_id = '$bus_id'";
            $result3 = $conn->query($sql3);

            if ($result3->num_rows > 0) {
                $row3 = $result3->fetch_assoc();
                $routes = $row3['routes'];

                // Create a single set containing all the data
                $single_set = array(
                    'routes' => $routes,
                    'blood_group' => $blood_group,
                    'contact_no' => $contact_no,
                    'date' => $date,
                );

                $final_data[] = $single_set;
            }
        }
    }
    
    $response = array('data' => $final_data);

    // Return the final data as JSON
    echo json_encode($response);
    // Return the final data as JSON
   
    
} else {
    // If user_id is not found in transporter_signup
    echo "User not found in transporter_signup.";
}

// Close the database connection
$conn->close();
?>
