<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $feedback_type = $_POST['feedback_type'];
    $description = $_POST['description'];
    $user_id = $_POST['user_id']; // Obtain user_id from login credentials

    // Insert data into the feedback table
    $sql = "INSERT INTO feedback (user_id, feedbackType, description) VALUES ('$user_id', '$feedback_type', '$description')";

    if ($conn->query($sql) === TRUE) {
        // Successful insertion
        $response = array('status' => 'Success', 'message' => 'Feedback submitted successfully.');
        echo json_encode($response);
    } else {
        // Error in database insertion
        $response = array('status' => 'Error', 'message' => 'Error: ' . $conn->error);
        echo json_encode($response);
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'Error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
