<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $name = $_POST['Name'];
    $designation = $_POST['Designation'];
    $user_id = $_POST['user_Id'];
    $password = $_POST['password'];
    $blood_group = $_POST['blood_group'];
    $contact_no = $_POST['contact_no'];
    $address = $_POST['Address'];

    // Check if the user_id already exists in transporter_signup
    $check_sql = "SELECT user_Id FROM transporter_signup WHERE user_Id = '$user_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // User already exists
        $response = array('status' => 'Error', 'message' => 'User already exists.');
        echo json_encode($response);
    } else {
        // Insert data into the transporter_signup table
        $sql = "INSERT INTO transporter_signup (Name ,DId,user_Id, password, blood_group, contact_no, Address) VALUES ('$name',
        '$designation','$user_id', '$password', '$blood_group', '$contact_no', '$address')";

        if ($conn->query($sql) === TRUE) {
            // Successful insertion
            $response = array('status' => 'Success', 'message' => 'User registration successful.');
            echo json_encode($response);
        } else {
            // Error in database insertion
            $response = array('status' => 'Error', 'message' => 'Error: ' . $conn->error);
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'Error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
