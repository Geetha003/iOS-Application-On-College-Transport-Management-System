<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the bus_id parameter is provided in the URL
if (isset($_GET['bus_id'])) {
    // Get the bus_id from the URL
    $bus_id = $_GET['bus_id'];

    // Initialize an array to store data
    $data = array();

    // Check if the bus_id exists in the bus_requests table
    $sql = "SELECT student_id, date FROM bus_requests WHERE busId = '$bus_id' and status='pending'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // For each student_id, fetch the corresponding route
            $student_id = $row['student_id'];
            $date = $row['date']; // Get the date
            
            // Query to get the route for the student
            $route_sql = "SELECT routes FROM bus_details WHERE bus_id = '$bus_id'";
            $route_result = $conn->query($route_sql);
            
            if ($route_result->num_rows > 0) {
                $route_row = $route_result->fetch_assoc();
                $route = $route_row['routes'];
                
                // Add the student_id, date, bus_id, and route to the data array
                $data[] = array(
                    'student_id' => $student_id,
                    'date' => $date,
                    'bus_id' => $bus_id,
                    'route' => $route,
                );
            }
        }
    }

    // Create a response array with the 'data' key
    $response = array('data' => $data);

    // Return the response as JSON
    echo json_encode($response);
} else {
    // Handle cases where bus_id is not provided in the URL
    $response = array('status' => 'Error', 'message' => 'Bus_id parameter missing.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
