<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the busId and user_id from the POST data
    $busId = $_POST['busId'];
    $user_id = $_POST['userId']; // Replace 'your_user_id' with the actual method to obtain the user_id

    // Check if the user already exists
    $check_sql = "SELECT * FROM bus_requests WHERE student_id = '$user_id' and status='Accepted'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // If the user exists, check the date
        $existing_record = $check_result->fetch_assoc();
        $existing_date = $existing_record['date'];

        // Calculate the difference between the existing date and the current date in days
        $date_diff = floor((strtotime(date("Y-m-d")) - strtotime($existing_date)) / (60 * 60 * 24));

        if ($date_diff >= 365) {  // If the difference is greater than or equal to one year (365 days)
            // Update the existing record with new bus ID, current date, and status as "pending"
            $update_sql = "UPDATE bus_requests SET busId = '$busId', date = CURDATE(), status = 'pending' WHERE student_id = '$user_id'";
            $update_result = $conn->query($update_sql);

            if ($update_result === TRUE) {
                // If the update is successful, return a success response
                $response = array('status' => 'Success', 'message' => 'Request sent successfully.');
                echo json_encode($response);
            } else {
                // If there is an error in the update, return an error response
                $response = array('status' => 'Error', 'message' => 'Failed to send request.');
                echo json_encode($response);
            }
        } else {
            // If the difference is less than one year, return an appropriate message
            $response = array('status' => 'Error', 'message' => 'User has an existing request');
            echo json_encode($response);
        }
    } else {
        // If the user does not exist, insert a new record
        $insert_sql = "INSERT INTO bus_requests (busId, student_id, status, date) VALUES ('$busId', '$user_id', 'pending', CURDATE())";
        $insert_result = $conn->query($insert_sql);

        if ($insert_result === TRUE) {
            // If the insertion is successful, return a success response
            $response = array('status' => 'Success', 'message' => 'Request sent successfully.');
            echo json_encode($response);
        } else {
            // If there is an error in the insertion, return an error response
            $response = array('status' => 'Error', 'message' => 'Failed to send request.');
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'Error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>