<?php
require_once('db_conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the POST request
    $user_id = $_POST['user_id'];
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Check if the new password and confirm password match
    if ($new_password !== $confirm_password) {
        $response = array('status' => 'Error', 'message' => 'New password and confirm password do not match.');
        echo json_encode($response);
        exit(); // Exit the script if passwords don't match
    }

    // Check if the old password matches the password in the transporter_signup table
    $check_sql = "SELECT * FROM `transporter_signup` WHERE user_Id = ? AND password = ?";
    $check_stmt = $conn->prepare($check_sql);

    if (!$check_stmt) {
        die("SQL query error: " . $conn->error);
    }

    $check_stmt->bind_param("ss", $user_id, $old_password);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows == 1) {
        // Old password is a match, update the password with the new password
        $update_sql = "UPDATE `transporter_signup` SET password = ? WHERE user_Id = ?";
        $update_stmt = $conn->prepare($update_sql);

        if (!$update_stmt) {
            die("SQL query error: " . $conn->error);
        }

        $update_stmt->bind_param("ss", $new_password, $user_id);

        if ($update_stmt->execute()) {
            // Password updated successfully
            $response = array('status' => 'success', 'message' => 'Password updated successfully.');
            echo json_encode($response);
        } else {
            // Error updating the password
            $response = array('status' => 'Error', 'message' => 'Failed to update password.');
            echo json_encode($response);
        }

        $update_stmt->close();
    } else {
        // Old password does not match
        $response = array('status' => 'Error', 'message' => 'Old password does not match.');
        echo json_encode($response);
    }

    $check_stmt->close();
    $conn->close();
}
?>
