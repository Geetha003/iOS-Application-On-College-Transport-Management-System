<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input data from the application
    $user_id = $_POST['user_Id'];
    $ques1 = $_POST['ques1'];
    $ques2 = $_POST['ques2'];
    $ques3 = $_POST['ques3'];
    $ques4 = $_POST['ques4'];
    $ques5 = $_POST['ques5'];
    $ques6 = $_POST['ques6'];
    $ques7 = $_POST['ques7'];
    $ques8 = $_POST['ques8'];
    $ques9 = $_POST['ques9'];
    $ques10 = $_POST['ques10'];
    $ques11 = $_POST['ques11'];
    $ques12 = $_POST['ques12'];
    $ques13 = $_POST['ques13'];
    $ques14 = $_POST['ques14'];
    $ques15 = $_POST['ques15'];
    $ques16 = $_POST['ques16'];
    $ques17 = $_POST['ques17'];
    $ques18 = $_POST['ques18'];
    $ques19 = $_POST['ques19'];
    $ques20 = $_POST['ques20'];
    $ques21 = $_POST['ques21'];
    $ques22 = $_POST['ques22'];
    $ques23 = $_POST['ques23'];
    $ques24 = $_POST['ques24'];
    $ques25 = $_POST['ques25'];
    $ques26 = $_POST['ques26'];
    $ques27 = $_POST['ques27'];
    $ques28 = $_POST['ques28'];
    $ques29 = $_POST['ques29'];
    $ques30 = $_POST['ques30'];
   

    // Check if the user_id already exists in transporter_signup
    $check_sql = "SELECT id FROM answers WHERE id = '$user_id'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        // User already exists
        $response = array('status' => 'error', 'message' => 'User already exists.');
        echo json_encode($response);
    } else {
        // Insert data into the transporter_signup table
        $sql = "INSERT INTO answers (id, ques1, ques2, ques3, ques4,ques5, ques6, ques7, ques8,ques9, ques10, ques11, ques12,ques13, ques14, ques15, ques16,ques17, ques18, ques19, ques20,
        ques21, ques22, ques23, ques24,ques25, ques26, ques27, ques28,ques29, ques30) VALUES ('$user_id',
        '$ques1','$ques2', '$ques3', '$ques4','$ques5','$ques6', '$ques7', '$ques8','$ques9','$ques10', '$ques11', '$ques12','$ques13','$ques14', '$ques15', '$ques16',
        '$ques17','$ques18', '$ques19', '$ques20','$ques21','$ques22', '$ques23', '$ques24','$ques25','$ques26', '$ques27', '$ques28','$ques29','$ques30')";

        if ($conn->query($sql) === TRUE) {
            // Successful insertion
            $response = array('status' => 'success', 'message' => 'User registration successful.');
            echo json_encode($response);
        } else {
            // Error in database insertion
            $response = array('status' => 'error', 'message' => 'Error: ' . $conn->error);
            echo json_encode($response);
        }
    }
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
