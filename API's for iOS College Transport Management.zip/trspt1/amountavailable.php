<?php

// Include the file with database connection details
include 'db_conn.php';

// Check if user_id is provided in the request
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Prepare and execute SQL query
    $stmt = $conn->prepare("SELECT amountAvailable FROM transporter_signup WHERE user_Id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if user is found
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $amountAvailable = $row['amountAvailable'];

        // Output result in the desired format
        $output = [
            'data' => [
                [
                    'user_id' => $user_id,
                    'amountAvailable' => $amountAvailable,
                ],
            ],
        ];

        echo json_encode($output);
    } else {
        echo json_encode(['error' => 'User not found']);
    }

    // Close statement
    $stmt->close();
} else {
    echo json_encode(['error' => 'Missing user_id parameter']);
}

// Note: Do not close the connection here if you plan to reuse it in other parts of your application.

?>
