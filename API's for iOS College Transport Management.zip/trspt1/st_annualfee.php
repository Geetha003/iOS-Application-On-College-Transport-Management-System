<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Get the user_id from the login credentials (replace this with your method of getting the user_id)
$user_id = $_GET['userId']; // Replace with your user_id retrieval code

// Initialize variables to store type and amount
$type = '';
$amount = '';

// Check if there is a matching row in the day_requests table
$sql = "SELECT id FROM bus_requests WHERE student_id = '$user_id' AND did = 1 AND status = 'Accepted'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id = $row['id'];

    // Retrieve the type and amount from the bus_request table for id=1
    $sql = "SELECT type, amount FROM bus_request WHERE id = 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $type = $row['type'];
        $amount = $row['amount'];
    }
    // else {
        // Handle the case where no matching row is found in the bus_request table
    //    $error_message = 'No matching record found in bus_request table.';
    //    echo json_encode(array('error' => $error_message));
    // }
} //else {
    // Handle the case where no matching row is found in the day_requests table
  //  $error_message = 'No matching record found in day_requests table.';
  //  echo json_encode(array('error' => $error_message));
//}

// Create an array with the retrieved data
$response_data = array(
    'type' => $type,
    'amount' => $amount,
);

// Wrap the response data in a "data" array
$response = array('data' => array($response_data));

// Return the response data as JSON
echo json_encode($response);

// Close the database connection
$conn->close();
?>
