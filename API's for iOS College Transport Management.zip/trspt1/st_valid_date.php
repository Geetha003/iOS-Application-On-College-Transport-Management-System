<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Get the user_id from the request
$user_id = $_GET['userId'];

// Initialize an array to store the final data
$final_data = array();

// Retrieve bus requests for the same user_id
$sql = "SELECT date FROM bus_requests WHERE student_id = '$user_id' AND status= 'Accepted'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $date = date("Y-m-d", strtotime($row['date'] . " +1 year")); // Add 1 year to the date
        $final_data[] = $date;
    }

    // Wrap the final data in a "data" array
    $response = array('data' => $final_data);

    // Return the final data as JSON
    echo json_encode($response);
} else {
    // If no records were found
    echo "No records found for the user.";
}

// Close the database connection
$conn->close();
?>
