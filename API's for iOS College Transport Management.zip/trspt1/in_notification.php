<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Get the user_id from the request
$user_id = $_GET['userId'];

// Check if the user_id matches any busInchargeID in bus_details
$sql1 = "SELECT bus_id FROM bus_details WHERE busInChargeID = '$user_id'";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    // Initialize an array to store the final data
    $final_data = array();

    // Fetch the bus_id
    $row1 = $result1->fetch_assoc();
    $bus_id = $row1['bus_id'];

    // Get the current date
    $current_date = date("Y-m-d");

    // Query day_request for matching rows with today's date and bus_id
    $sql2 = "SELECT student_id, date FROM day_request WHERE busId = '$bus_id' AND date = '$current_date' AND status ='pending'";
    $result2 = $conn->query($sql2);

    if ($result2->num_rows > 0) {
        while ($row2 = $result2->fetch_assoc()) {
            $student_id = $row2['student_id'];
            $date = $row2['date'];

            // Check if student_id matches user_id in transporter_signup
            $sql3 = "SELECT user_Id, Name FROM transporter_signup WHERE user_Id = '$student_id'";
            $result3 = $conn->query($sql3);

            if ($result3->num_rows > 0) {
                $row3 = $result3->fetch_assoc();
                $final_data[] = array(
                    'bus_id' => $bus_id,
                    'user_id' => $row3['user_Id'],
                    'name' => $row3['Name'],
                    'date' => $date,
                );
            }
        }
    }

    // Wrap the final data in a "data" array
    $response = array('data' => $final_data);

    // Return the final data as JSON
    echo json_encode($response);
    
} else {
    // If user_id is not found in bus_details
    echo "User not found in bus_details.";
}

// Close the database connection
$conn->close();
?>