<?php
// Include your database connection code here (e.g., db_conn.php)
require_once('db_conn.php');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the route input from the POST data
    $route = $_POST['route'];

    // Initialize an array to store the results
    $results = array();

    // Retrieve matching rows from the bus_details table based on the route
    $sql = "SELECT bus_id, routes FROM bus_details WHERE routes LIKE '%$route%'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $bus_id = $row['bus_id'];
            $routes = $row['routes'];

            // Create a result entry
            $result_entry = array(
                'bus_id' => $bus_id,
                'route' => $routes,
            );

            // Add the result entry to the results array
            $results[] = $result_entry;
        }
    }

    // Return the results as JSON
    echo json_encode($results);
} else {
    // Handle non-POST requests (e.g., return an error response)
    $response = array('Status' => 'error', 'message' => 'Invalid request method.');
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
